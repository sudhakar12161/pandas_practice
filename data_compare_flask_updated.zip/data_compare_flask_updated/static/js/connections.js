const connState = {
  types: {},
  items: [],
};

const fieldsByType = {
  FILE_DELIMITED: ["name", "header", "field_delim", "trim_space", "field_enclosed_by"],
  CLOUD_DELIMITED: ["name", "header", "field_delim", "trim_space", "field_enclosed_by", "hostname"],
  FILE_EXCEL: ["name", "header", "trim_space"],
  CLOUD_EXCEL: ["name", "header", "trim_space", "hostname"],
  DATABASE_SNOWFLAKE: ["name", "username", "password", "hostname", "database_name", "schema_name", "port", "authtype"],
  DATABASE_ORACLE: ["name", "username", "password", "hostname", "database_name", "schema_name", "port"],
  DATABASE_DUCKDB: ["name", "hostname"],
  DATABASE_DELTA: ["name", "hostname"],
};

function toTitleLabel(value) {
  return value
    .replaceAll("_", " ")
    .toLowerCase()
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function inputTemplate(field) {
  if (field === "type") {
    return `
      <label>Type
        <select id="conn-type" class="field">
          <option value="">Select type</option>
          ${Object.entries(connState.types)
            .map(([key, value]) => `<option value="${key}">${value}</option>`)
            .join("")}
        </select>
      </label>
    `;
  }

  if (field === "header" || field === "trim_space") {
    return `
      <label>${field.replace("_", " ")}
        <select id="conn-${field}" class="field">
          <option value="true">True</option>
          <option value="false">False</option>
        </select>
      </label>
    `;
  }

  if (field === "field_delim") {
    return `
      <label>Field Delimiter
        <select id="conn-field_delim" class="field">
          <option value=",">Comma (,)</option>
          <option value="\\t">Tab (\\t)</option>
          <option value="|">Pipe (|)</option>
          <option value=" ">Space</option>
        </select>
      </label>
    `;
  }

  if (field === "field_enclosed_by") {
    return `
      <label>Field Optionally Enclosed By
        <select id="conn-field_enclosed_by" class="field">
          <option value="None">None</option>
          <option value='"'>"</option>
          <option value="'">'</option>
        </select>
      </label>
    `;
  }

  if (field === "authtype") {
    return `
      <label>Auth Type
        <select id="conn-authtype" class="field">
          <option value="externalbrowser">externalbrowser</option>
          <option value="username/password">username/password</option>
        </select>
      </label>
    `;
  }

  const type = field === "password" ? "password" : field === "port" ? "number" : "text";
  return `
    <label>${toTitleLabel(field)}
      <input id="conn-${field}" class="field" type="${type}">
    </label>
  `;
}

function renderConnectionForm() {
  const container = document.getElementById("connection-form");
  const selectedType = document.getElementById("conn-type")?.value || "";
  let dynamicFields = fieldsByType[selectedType] || [];
  const selectedAuthType = document.getElementById("conn-authtype")?.value || "externalbrowser";
  if (selectedType === "DATABASE_SNOWFLAKE" && selectedAuthType === "externalbrowser") {
    dynamicFields = dynamicFields.filter((field) => field !== "password");
  }

  container.innerHTML = [inputTemplate("type"), ...dynamicFields.map(inputTemplate)].join("");
  const typeSelect = document.getElementById("conn-type");
  if (selectedType) typeSelect.value = selectedType;
  typeSelect.addEventListener("change", () => {
    setErrorBox("connection-error", "");
    renderConnectionForm();
  });
  const authSelect = document.getElementById("conn-authtype");
  authSelect?.addEventListener("change", () => {
    setErrorBox("connection-error", "");
    renderConnectionForm();
  });
}

function buildPayload() {
  const type = document.getElementById("conn-type").value;
  const payload = { type };
  const dynamicFields = fieldsByType[type] || [];

  for (const field of dynamicFields) {
    const rawValue = document.getElementById(`conn-${field}`)?.value;
    if (field === "header" || field === "trim_space") payload[field] = rawValue === "true";
    else if (field === "port") payload[field] = rawValue ? Number(rawValue) : null;
    else payload[field] = rawValue;
  }
  return payload;
}

function renderConnectionsTable() {
  const search = document.getElementById("connection-search").value.toLowerCase();
  const filtered = connState.items.filter(
    (item) => !search || item.name.toLowerCase().includes(search) || item.type.toLowerCase().includes(search)
  );
  const fileItems = filtered.filter((item) => ["FILE", "CLOUD"].some((prefix) => item.type.startsWith(prefix)));
  const dbItems = filtered.filter((item) => item.type.startsWith("DATABASE"));
  document.getElementById("file-conn-count").textContent = `(${fileItems.length})`;
  document.getElementById("db-conn-count").textContent = `(${dbItems.length})`;

  document.getElementById("file-connections-body").innerHTML = fileItems
    .map(
      (item) => `
      <tr>
        <td>${escapeHtml(item.name)}</td>
        <td>${escapeHtml(item.type)}</td>
        <td>${escapeHtml(item.header)}</td>
        <td>${escapeHtml(item.field_delim || "-")}</td>
        <td>${fmtDate(item.created_at)}</td>
      </tr>
    `
    )
    .join("");

  document.getElementById("db-connections-body").innerHTML = dbItems
    .map(
      (item) => `
      <tr>
        <td>${escapeHtml(item.name)}</td>
        <td>${escapeHtml(item.type)}</td>
        <td>${escapeHtml(item.hostname || "-")}</td>
        <td>${escapeHtml(item.database_name || "-")}</td>
        <td>${escapeHtml(item.schema_name || "-")}</td>
        <td>${fmtDate(item.created_at)}</td>
      </tr>
    `
    )
    .join("");
}

async function refreshConnections() {
  const response = await apiGet("/api/connections");
  connState.items = response.items;
  renderConnectionsTable();
}

async function initializeConnectionsPage() {
  try {
    setErrorBox("connection-error", "");
    const response = await apiGet("/api/connection-types");
    connState.types = response.types;
    renderConnectionForm();
    await refreshConnections();
  } catch (error) {
    setErrorBox("connection-error", error.message);
    showToast(error.message, "error");
  }
}

document.getElementById("btn-add-connection").addEventListener("click", async () => {
  try {
    setErrorBox("connection-error", "");
    showLoading("Saving connection...");
    const payload = buildPayload();
    await apiPost("/api/connections", payload);
    showToast("Connection added", "success");
    await refreshConnections();
    renderConnectionForm();
  } catch (error) {
    setErrorBox("connection-error", error.message);
    showToast(error.message, "error");
  } finally {
    hideLoading();
  }
});

document.getElementById("connection-search").addEventListener("input", renderConnectionsTable);

initializeConnectionsPage();
