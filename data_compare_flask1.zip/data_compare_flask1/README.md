# Data Comparison Tool (Flask + PySpark)

This project provides a web-based data comparison utility with:

- `Data Compare` page for source vs target configuration, schema compare, data analysis, and data compare report.
- `View Schema` page for schema preview, editable JSON save, delete, search, and Excel download.
- `View Connections` page for adding/searching connection metadata and viewing file/database groups.

## Tech stack

- Flask UI and API
- PySpark for schema/data operations
- DuckDB for metadata tables (`CONNECTIONS`, `SCHEMAS`)

## Setup

```bash
python -m venv .venv
. .venv/Scripts/activate
pip install -r requirements.txt
python run.py
```

Open `http://127.0.0.1:5000`.

## Notes

- Spark sessions are created lazily and reused for 30 minutes.
- Database and cloud connections are only used when compare/schema actions are triggered.
- Local uploaded files are stored in `uploads/`.
- Compare reports are generated in `exports/` with:
  - `Summary` sheet
  - `Data` sheet (mismatch rows, max 10000)

