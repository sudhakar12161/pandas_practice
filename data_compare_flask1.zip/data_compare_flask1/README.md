# Data Compare Tool (Flask + PySpark + Polars)

Web application to compare datasets between Source and Target with:

- Connection management
- Schema management
- Schema compare
- Data profiling/analyze
- Data compare with column mapping
- Side-wise data preview (paginated)
- Excel export reports

Supports selecting compare engine per run:

- `PySpark`
- `Polars`

## 1. High-Level Architecture

The app is organized into 3 layers:

1. UI layer (Jinja + JS)
- Renders pages and captures user actions.

2. API layer (Flask routes)
- Validates requests, orchestrates services, returns JSON.

3. Service/data layer
- Connection/schema CRUD
- Data loading/inference/compare logic
- Export generation

Metadata store:

- DuckDB file `app_meta.duckdb`
- Tables:
  - `CONNECTIONS`
  - `SCHEMAS`

Runtime directories:

- `uploads/` local uploaded files
- `exports/` generated Excel outputs
- `logs/` rotating backend logs
- `.ivy2/` Spark package cache

## 2. Folder Structure

```text
data_compare_flask/
  app/
    __init__.py
    config.py
    logging_config.py
    db/
      repository.py
    routes/
      pages.py
      api.py
    services/
      spark_session.py
      datasource_loader.py
      compare_service.py
      polars_loader.py
      polars_compare_service.py
      connection_service.py
      schema_service.py
      job_service.py
    utils/
      constants.py
      schema_utils.py
      validators.py
  templates/
    base.html
    data_compare.html
    view_schema.html
    view_connections.html
  static/
    css/styles.css
    js/common.js
    js/data_compare.js
    js/schema.js
    js/connections.js
  uploads/
  exports/
  logs/
  app_meta.duckdb
  requirements.txt
  run.py
```

## 3. What Each Key File Does

### App bootstrap/config

- `run.py`
  - Entry point (`python run.py`).

- `app/__init__.py`
  - Creates Flask app.
  - Loads config.
  - Configures logging.
  - Wires services and blueprints.
  - Creates both compare services:
    - `compare_pyspark`
    - `compare_polars`

- `app/config.py`
  - Global settings:
    - paths (`DB_PATH`, `UPLOAD_DIR`, `EXPORT_DIR`, `LOG_DIR`)
    - Spark TTL/options
    - PySpark file-size partition tuning:
      - `SPARK_SMALL_FILE_MB`
      - `SPARK_LARGE_FILE_MB`
      - `SPARK_SMALL_FILE_PARTITIONS`
      - `SPARK_LARGE_FILE_PARTITION_MULTIPLIER`
      - current defaults are tuned for small files (`20MB`, `1` partition)
    - schema sampling
    - compare limits
    - optional Snowflake Spark package settings

- `app/logging_config.py`
  - Backend logging setup with daily rotation to `logs/backend.log`.

### DB/repository

- `app/db/repository.py`
  - DuckDB connection wrapper.
  - Initializes `CONNECTIONS` and `SCHEMAS`.
  - Helper methods: `fetch_all`, `fetch_one`, `execute`.

### Routes

- `app/routes/pages.py`
  - HTML page routes:
    - Data Compare
    - View Schema
    - View Connections

- `app/routes/api.py`
  - JSON APIs for:
    - connection CRUD
    - schema CRUD/download
    - upload
    - schema preview
    - schema compare
    - analyze
    - compare data
    - async jobs
    - export download
  - Chooses engine by request field: `framework = pyspark|polars`.

### Services

- `app/services/connection_service.py`
  - Connection CRUD + validation integration.

- `app/services/schema_service.py`
  - Schema CRUD.
  - Normalizes schema format to `{column_name: datatype}`.
  - Uses shared canonical type mapping so schemas are engine-agnostic.

- `app/services/job_service.py`
  - Async job executor/polling support for analyze/compare jobs.

- `app/services/spark_session.py`
  - Lazy Spark session with TTL reuse.
  - Local Spark safety defaults.
  - Optional Spark package/JAR wiring.

- `app/services/datasource_loader.py`
  - PySpark data load/infer by connection type.
  - Uses database metadata for schema infer where applicable.
  - For CSV with selected schema, applies Spark schema at read-time and enables date inference (`preferDate`).

- `app/services/compare_service.py`
  - PySpark-based:
    - resolve schema
    - analyze metrics
    - compare data
    - export Excel (summary + data tabs)
  - Uses numeric-tolerant value matching (for example `1` vs `1.0`) and preserves source column order in compare/export paths.

- `app/services/polars_loader.py`
  - Polars data load/infer by connection type.
  - Includes Snowflake/Oracle/Delta/DuckDB/file paths.
  - Snowflake operations include fast-fail behavior and 30-second wrapper timeout.

- `app/services/polars_compare_service.py`
  - Polars-based analyze/compare logic.
  - Reuses export/report helpers from base compare service.
  - Uses column-wise aggregated mismatch stats with numeric-tolerant value matching.

### Utilities

- `app/utils/constants.py`
  - Connection type constants and family sets.

- `app/utils/schema_utils.py`
  - Shared schema normalization and canonical datatype mapping.
  - Keeps schema definitions generic for reuse across PySpark and Polars.

- `app/utils/validators.py`
  - Request payload validation.
  - Includes Snowflake hostname format validation.

### Frontend

- `templates/*.html`
  - Page layouts, sections, modals.

- `static/js/common.js`
  - API wrappers, loading overlay, toast, shared helpers.

- `static/js/data_compare.js`
  - Data Compare UI logic:
    - side forms
    - schema loading
    - mapping modal
    - analyze/compare actions
    - framework selector (`PySpark` / `Polars`)
    - side data preview modal (500 row cap, 100/page)

- `static/js/schema.js`
  - View Schema page behavior.
  - Schema display/infer requests are forced through Polars for all source types.

- `static/js/connections.js`
  - View Connections page behavior including add/edit/delete modal flows.

## 4. Dependency Flow

### Request flow

1. Browser action
2. `static/js/*` calls `/api/*`
3. `api.py` validates and builds payload
4. API picks compare service:
   - `compare_pyspark` or `compare_polars`
5. Service calls loader:
   - `datasource_loader.py` (PySpark) or `polars_loader.py` (Polars)
6. Service computes output and optional Excel
7. API returns JSON
8. UI renders tables/tiles/download links

### Engine isolation

- PySpark and Polars are decoupled paths.
- Switching framework should not alter the other engine’s runtime logic.
- Snowflake connector issues in Spark do not affect Polars path, and vice versa.
- Saved schema definitions are canonical/generic and can be applied in either engine.

## 5. Supported Sources by Engine

### PySpark

- Files: CSV/TSV, Excel
- Cloud files: CSV/TSV, Excel (path based)
- Databases: Snowflake, Oracle, DuckDB, Delta

### Polars

- Files: CSV/TSV, Excel
- Cloud files: CSV/TSV, Excel (path based)
- Databases:
  - DuckDB
  - Snowflake (via `snowflake-connector-python`)
  - Oracle (via `oracledb`)
  - Delta (via `deltalake`)

## 6. Setup

## 6.1 Create and activate venv

```powershell
python -m venv dq_flask
.\dq_flask\Scripts\Activate.ps1
```

## 6.2 Install dependencies

```powershell
pip install -r requirements.txt
```

## 6.3 Run app

```powershell
python run.py
```

Open:

- `http://127.0.0.1:5000`

## 7. Required Python Packages

From `requirements.txt`:

- Flask
- duckdb
- pandas
- openpyxl
- pyspark==3.5.8
- polars
- snowflake-connector-python
- oracledb
- deltalake

## 8. Snowflake Configuration Notes

There are 2 Snowflake paths:

1. PySpark Snowflake
- Needs Spark connector JARs (`spark-snowflake` + `snowflake-jdbc`) if using Spark path.
- Optional env settings in `config.py`:
  - `SNOWFLAKE_SPARK_PACKAGE`
  - `SNOWFLAKE_JDBC_PACKAGE`
  - `SPARK_EXTRA_JARS`

2. Polars Snowflake
- Uses `snowflake-connector-python` directly.
- No Spark Snowflake JAR needed for this path.

For `externalbrowser` auth:

- Do not use password.
- `authenticator=externalbrowser` is used.

## 9. Logging

Logs are written to:

- `logs/backend.log`

Rotation:

- Daily rotation (midnight)
- Retention ~30 files

Format:

- `timestamp | level | logger | message`

You will see logs from:

- API (`data_compare.api`)
- Compare services (`data_compare.compare.*`)
- Polars loader (`data_compare.loader.polars`)
- Flask server (`werkzeug`)

## 10. Async Jobs

Long operations are run via async job service:

- Analyze Data
- Compare Data

Flow:

1. Submit job
2. Poll `/api/jobs/<job_id>`
3. Render result when completed

## 11. Output Files

### Uploads

- Uploaded files stored in `uploads/`
- Filenames are prefixed with UUID for uniqueness

### Exports

- Stored in `exports/`
- Analyze export:
  - `Source Data Statistics`
  - `Target Data Statistics`
- Compare export:
  - `Summary`
  - `Data` (with `Matched_Ind`, PK first, SRC/TGT pairs)
  - `Data` tab includes only non-matched records (`Mismatched`, `Only in Source`, `Only in Target`) and places them first by design.

## 12. Common Troubleshooting

### 1) `TemplateNotFound`

- Ensure `templates/` folder and file names match route usage.

### 2) Spark gateway errors / version mismatch

- Use venv Python consistently.
- Avoid global `SPARK_HOME` conflicts.
- Restart app after changing Spark env.

### 3) Snowflake hangs/slow failure

- Validate hostname/account format.
- For Polars path, 30-second timeout wrapper is applied.
- Check `logs/backend.log` for stage logs.

### 4) Connector errors in Spark

- Verify compatible Spark/Snowflake connector versions.
- Clear `.ivy2` Snowflake artifacts if old incompatible JARs remain.

### 5) Missing module errors

- Reinstall from `requirements.txt` in active venv.

## 13. Development Notes

- Keep engine-specific logic in separate files (`*_loader.py`, `*_compare_service.py`).
- API should only orchestrate and validate.
- Add new source types by implementing both loaders where needed.
- Prefer reusable export/report helpers to keep output consistent across engines.

## 14. Recent UX Rules Implemented

- Mapping editor warning bar includes:
  - duplicate target mappings
  - unmapped source columns
  - potential mismatch mappings (source name differs from selected target name)
- Column mapping display order:
  - PK columns first
  - then source column order
- Schema compare order:
  - source order first, then target-only columns
- Universal datatype normalization for schema compare:
  - examples: `TEXT`, `VARCHAR`, `string` -> `STRING`
- Data preview:
  - one button per side in Data Compare
  - popup table with sticky header
  - page size 100, max first 500 rows
  - requires Schema Name (cannot be `None`)
- Cross-side schema mode options in Data Compare:
  - Source: `Infer Target Schema`
  - Target: `Infer Source Schema`
  - these apply the other side schema during compare
- View Connections:
  - mandatory fields marked with `*`
  - richer table display (excluding password)

## 15. Compare Semantics

- Exclude columns are applied consistently to:
  - Data Preview
  - Column Mapping input set
  - Analyze Data
  - Compare Data
- Null-safe comparisons:
  - if both values are null, they are treated as matched
  - applied in value-level compare for both PySpark and Polars paths
