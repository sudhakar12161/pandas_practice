# Data Comparison Tool (Flask + PySpark)

This project provides a web-based data comparison utility with:

- `Data Compare` page for source vs target configuration, schema compare, data analysis, and data compare report.
- `View Schema` page for schema preview, editable JSON save, delete, search, and Excel download.
- `View Connections` page for adding/searching connection metadata and viewing file/database groups.

## Tech stack

- Flask UI and API
- PySpark for schema/data operations
- DuckDB for metadata tables (`CONNECTIONS`, `SCHEMAS`)

## Setup

```bash
python -m venv .venv
. .venv/Scripts/activate
pip install -r requirements.txt
python run.py
```

Open `http://127.0.0.1:5000`.

## Notes

- Spark sessions are created lazily and reused for 30 minutes.
- Database and cloud connections are only used when compare/schema actions are triggered.
- Local uploaded files are stored in `uploads/`.
- Compare reports are generated in `exports/` with:
  - `Summary` sheet
  - `Data` sheet (mismatch rows, max 10000)

## Snowflake Connector (Spark)

Yes, Snowflake needs connector JARs when used from Spark.

Option 1: Auto-download from Maven (set before `python run.py`)

```bash
set SNOWFLAKE_SPARK_PACKAGE=<compatible-snowflake-spark-package>
set SNOWFLAKE_JDBC_PACKAGE=<compatible-snowflake-jdbc-package>
```

Option 2: Use local JAR files (offline/corporate network)

```bash
set SPARK_EXTRA_JARS=C:\path\to\spark-snowflake.jar,C:\path\to\snowflake-jdbc.jar
```

If package versions are not compatible with your Spark build, switch to `SPARK_EXTRA_JARS` with validated JARs for your environment.
This app does not enable Snowflake packages by default to avoid impacting non-Snowflake reads (like CSV schema inference).
