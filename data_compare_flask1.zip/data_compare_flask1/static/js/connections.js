const connState = {
  types: {},
  items: [],
  editConnectionId: null,
};

const fieldsByType = {
  FILE_DELIMITED: ["name", "header", "field_delim", "trim_space", "field_enclosed_by"],
  CLOUD_DELIMITED: ["name", "header", "field_delim", "trim_space", "field_enclosed_by", "hostname"],
  FILE_EXCEL: ["name", "header", "trim_space"],
  CLOUD_EXCEL: ["name", "header", "trim_space", "hostname"],
  DATABASE_SNOWFLAKE: ["name", "username", "password", "hostname", "database_name", "schema_name", "port", "authtype"],
  DATABASE_ORACLE: ["name", "username", "password", "hostname", "database_name", "schema_name", "port"],
  DATABASE_DUCKDB: ["name", "hostname"],
  DATABASE_DELTA: ["name", "hostname"],
};

function requiredFieldsByType(type, authType) {
  if (!type) return new Set();
  if (type === "FILE_DELIMITED" || type === "CLOUD_DELIMITED") return new Set(["name", "header", "field_delim", "trim_space"]);
  if (type === "FILE_EXCEL" || type === "CLOUD_EXCEL") return new Set(["name", "header", "trim_space"]);
  if (type === "DATABASE_SNOWFLAKE") {
    const req = new Set(["name", "username", "hostname", "database_name", "schema_name", "authtype"]);
    if (authType !== "externalbrowser") req.add("password");
    return req;
  }
  if (type === "DATABASE_ORACLE") return new Set(["name", "username", "password", "hostname", "database_name", "schema_name", "port"]);
  if (type === "DATABASE_DUCKDB" || type === "DATABASE_DELTA") return new Set(["name", "hostname"]);
  return new Set();
}

function toTitleLabel(value) {
  return value.replaceAll("_", " ").toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
}

function inputTemplate(field, prefix, value = "", required = false) {
  const star = required ? " *" : "";
  if (field === "type") {
    return `
      <label>Type${star}
        <select id="${prefix}-type" class="field">
          <option value="">Select type</option>
          ${Object.entries(connState.types)
            .map(([key, label]) => `<option value="${key}" ${String(value) === String(key) ? "selected" : ""}>${escapeHtml(label)}</option>`)
            .join("")}
        </select>
      </label>
    `;
  }

  if (field === "header" || field === "trim_space") {
    const selected = String(value ?? true);
    return `
      <label>${field.replace("_", " ")}${star}
        <select id="${prefix}-${field}" class="field">
          <option value="true" ${selected === "true" ? "selected" : ""}>True</option>
          <option value="false" ${selected === "false" ? "selected" : ""}>False</option>
        </select>
      </label>
    `;
  }

  if (field === "field_delim") {
    return `
      <label>Field Delimiter${star}
        <select id="${prefix}-field_delim" class="field">
          <option value="," ${value === "," ? "selected" : ""}>Comma (,)</option>
          <option value="\\t" ${value === "\\t" ? "selected" : ""}>Tab (\\t)</option>
          <option value="|" ${value === "|" ? "selected" : ""}>Pipe (|)</option>
          <option value=" " ${value === " " ? "selected" : ""}>Space</option>
        </select>
      </label>
    `;
  }

  if (field === "field_enclosed_by") {
    return `
      <label>Field Optionally Enclosed By${star}
        <select id="${prefix}-field_enclosed_by" class="field">
          <option value="None" ${value === "None" ? "selected" : ""}>None</option>
          <option value='"' ${value === '"' ? "selected" : ""}>"</option>
          <option value="'" ${value === "'" ? "selected" : ""}>'</option>
        </select>
      </label>
    `;
  }

  if (field === "authtype") {
    const selected = value || "externalbrowser";
    return `
      <label>Auth Type${star}
        <select id="${prefix}-authtype" class="field">
          <option value="externalbrowser" ${selected === "externalbrowser" ? "selected" : ""}>externalbrowser</option>
          <option value="username/password" ${selected === "username/password" ? "selected" : ""}>username/password</option>
        </select>
      </label>
    `;
  }

  const type = field === "password" ? "password" : field === "port" ? "number" : "text";
  const safeValue = value == null ? "" : escapeHtml(value);
  const placeholder = field === "password" && prefix === "edit-conn" ? ' placeholder="Leave blank to keep existing password"' : "";
  return `
    <label>${toTitleLabel(field)}${star}
      <input id="${prefix}-${field}" class="field" type="${type}" value="${safeValue}"${placeholder}>
    </label>
  `;
}

function fieldsFor(type, authType) {
  let dynamicFields = fieldsByType[type] || [];
  if (type === "DATABASE_SNOWFLAKE" && authType === "externalbrowser") {
    dynamicFields = dynamicFields.filter((field) => field !== "password");
  }
  return dynamicFields;
}

function buildPayload(prefix, type) {
  const payload = { type };
  const authType = document.getElementById(`${prefix}-authtype`)?.value || "";
  const dynamicFields = fieldsFor(type, authType);
  for (const field of dynamicFields) {
    const rawValue = document.getElementById(`${prefix}-${field}`)?.value;
    if (field === "header" || field === "trim_space") payload[field] = rawValue === "true";
    else if (field === "port") {
      if (rawValue) payload[field] = Number(rawValue);
      else if (type !== "DATABASE_SNOWFLAKE") payload[field] = null;
    } else payload[field] = rawValue;
  }
  return payload;
}

function renderConnectionForm() {
  const container = document.getElementById("connection-form");
  const type = document.getElementById("new-conn-type")?.value || "";
  const authType = document.getElementById("new-conn-authtype")?.value || "externalbrowser";
  const dynamicFields = fieldsFor(type, authType);
  const required = requiredFieldsByType(type, authType);
  container.innerHTML = [
    inputTemplate("type", "new-conn", type, true),
    ...dynamicFields.map((f) => inputTemplate(f, "new-conn", "", required.has(f))),
  ].join("");

  document.getElementById("new-conn-type").addEventListener("change", () => {
    setErrorBox("connection-error", "");
    renderConnectionForm();
  });
  document.getElementById("new-conn-authtype")?.addEventListener("change", () => {
    setErrorBox("connection-error", "");
    renderConnectionForm();
  });
}

function renderEditForm() {
  const modal = document.getElementById("connection-edit-modal");
  const form = document.getElementById("connection-edit-form");
  const row = connState.items.find((item) => String(item.id) === String(connState.editConnectionId));
  if (!row) {
    modal.classList.add("hidden");
    return;
  }

  const authType = document.getElementById("edit-conn-authtype")?.value || row.authtype || "externalbrowser";
  const dynamicFields = fieldsFor(row.type, authType);
  const required = requiredFieldsByType(row.type, authType);
  form.innerHTML = [
    `<div class="small-label span-all">Type: ${escapeHtml(row.type)}</div>`,
    ...dynamicFields.map((f) => inputTemplate(f, "edit-conn", row[f], required.has(f))),
  ].join("");

  document.getElementById("edit-conn-authtype")?.addEventListener("change", () => {
    setErrorBox("connection-edit-error", "");
    renderEditForm();
  });
}

function renderConnectionsTable() {
  const search = document.getElementById("connection-search").value.toLowerCase();
  const filtered = connState.items.filter(
    (item) => !search || item.name.toLowerCase().includes(search) || item.type.toLowerCase().includes(search)
  );
  const fileItems = filtered.filter((item) => ["FILE", "CLOUD"].some((prefix) => item.type.startsWith(prefix)));
  const dbItems = filtered.filter((item) => item.type.startsWith("DATABASE"));
  document.getElementById("file-conn-count").textContent = `(${fileItems.length})`;
  document.getElementById("db-conn-count").textContent = `(${dbItems.length})`;

  const actionButtons = (item) =>
    `<button class="btn btn-secondary btn-small" data-edit-conn-id="${item.id}">Edit</button>
     <button class="btn btn-danger btn-small" data-del-conn-id="${item.id}">Delete</button>`;

  document.getElementById("file-connections-body").innerHTML = fileItems
    .map(
      (item) => `
      <tr>
        <td>${escapeHtml(item.name)}</td>
        <td>${escapeHtml(item.type)}</td>
        <td>${escapeHtml(item.hostname || "-")}</td>
        <td>${escapeHtml(item.header)}</td>
        <td>${escapeHtml(item.field_delim || "-")}</td>
        <td>${escapeHtml(item.trim_space)}</td>
        <td>${escapeHtml(item.field_enclosed_by || "-")}</td>
        <td>${fmtDate(item.created_at)}</td>
        <td>${actionButtons(item)}</td>
      </tr>
    `
    )
    .join("");

  document.getElementById("db-connections-body").innerHTML = dbItems
    .map(
      (item) => `
      <tr>
        <td>${escapeHtml(item.name)}</td>
        <td>${escapeHtml(item.type)}</td>
        <td>${escapeHtml(item.hostname || "-")}</td>
        <td>${escapeHtml(item.port || "-")}</td>
        <td>${escapeHtml(item.username || "-")}</td>
        <td>${escapeHtml(item.database_name || "-")}</td>
        <td>${escapeHtml(item.schema_name || "-")}</td>
        <td>${escapeHtml(item.authtype || "-")}</td>
        <td>${fmtDate(item.created_at)}</td>
        <td>${actionButtons(item)}</td>
      </tr>
    `
    )
    .join("");

  document.querySelectorAll("button[data-del-conn-id]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const connId = btn.getAttribute("data-del-conn-id");
      const row = connState.items.find((item) => String(item.id) === String(connId));
      const name = row?.name || `ID ${connId}`;
      if (!window.confirm(`Delete connection "${name}"?`)) return;
      try {
        setErrorBox("connection-error", "");
        showLoading("Deleting connection...");
        await apiDelete(`/api/connections/${connId}`);
        showToast("Connection deleted", "success");
        await refreshConnections();
      } catch (error) {
        setErrorBox("connection-error", error.message);
        showToast(error.message, "error");
      } finally {
        hideLoading();
      }
    });
  });

  document.querySelectorAll("button[data-edit-conn-id]").forEach((btn) => {
    btn.addEventListener("click", () => {
      setErrorBox("connection-edit-error", "");
      connState.editConnectionId = btn.getAttribute("data-edit-conn-id");
      renderEditForm();
      document.getElementById("connection-edit-modal").classList.remove("hidden");
    });
  });
}

async function refreshConnections() {
  const response = await apiGet("/api/connections");
  connState.items = response.items;
  renderConnectionsTable();
}

async function initializeConnectionsPage() {
  try {
    setErrorBox("connection-error", "");
    const response = await apiGet("/api/connection-types");
    connState.types = response.types;
    renderConnectionForm();
    await refreshConnections();
  } catch (error) {
    setErrorBox("connection-error", error.message);
    showToast(error.message, "error");
  }
}

document.getElementById("btn-add-connection").addEventListener("click", async () => {
  try {
    setErrorBox("connection-error", "");
    showLoading("Saving connection...");
    const type = document.getElementById("new-conn-type").value;
    const payload = buildPayload("new-conn", type);
    await apiPost("/api/connections", payload);
    showToast("Connection added", "success");
    await refreshConnections();
    renderConnectionForm();
  } catch (error) {
    setErrorBox("connection-error", error.message);
    showToast(error.message, "error");
  } finally {
    hideLoading();
  }
});

document.getElementById("btn-save-connection-edit").addEventListener("click", async () => {
  try {
    const connId = connState.editConnectionId;
    const row = connState.items.find((item) => String(item.id) === String(connId));
    if (!row) throw new Error("Connection not found");
    setErrorBox("connection-edit-error", "");
    showLoading("Updating connection...");
    const payload = buildPayload("edit-conn", row.type);
    await apiPut(`/api/connections/${connId}`, payload);
    showToast("Connection updated", "success");
    document.getElementById("connection-edit-modal").classList.add("hidden");
    await refreshConnections();
  } catch (error) {
    setErrorBox("connection-edit-error", error.message);
    showToast(error.message, "error");
  } finally {
    hideLoading();
  }
});

document.getElementById("btn-cancel-connection-edit").addEventListener("click", () => {
  document.getElementById("connection-edit-modal").classList.add("hidden");
});

document.getElementById("connection-search").addEventListener("input", renderConnectionsTable);

initializeConnectionsPage();
