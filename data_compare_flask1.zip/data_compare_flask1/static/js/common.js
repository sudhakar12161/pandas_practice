async function parseApiResponse(response) {
  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return response.json();
  }
  const text = await response.text();
  return { error: text || "Unexpected non-JSON response from server" };
}

async function apiGet(url) {
  const response = await fetch(url);
  const payload = await parseApiResponse(response);
  if (!response.ok) {
    throw new Error(payload.error || (payload.errors ? payload.errors.join(", ") : "Request failed"));
  }
  return payload;
}

async function apiPost(url, data, isFormData = false) {
  const options = {
    method: "POST",
    headers: isFormData ? {} : { "Content-Type": "application/json" },
    body: isFormData ? data : JSON.stringify(data),
  };
  const response = await fetch(url, options);
  const payload = await parseApiResponse(response);
  if (!response.ok) {
    throw new Error(payload.error || (payload.errors ? payload.errors.join(", ") : "Request failed"));
  }
  return payload;
}

async function apiDelete(url) {
  const response = await fetch(url, { method: "DELETE" });
  const payload = await parseApiResponse(response);
  if (!response.ok) {
    throw new Error(payload.error || (payload.errors ? payload.errors.join(", ") : "Request failed"));
  }
  return payload;
}

function showToast(message, type = "info") {
  const toast = document.getElementById("toast");
  if (!toast) return;
  toast.textContent = message;
  toast.className = `toast ${type}`;
  setTimeout(() => toast.classList.add("hidden"), 3000);
}

function showLoading(message) {
  const overlay = document.getElementById("global-loading");
  const text = document.getElementById("global-loading-text");
  if (!overlay || !text) return;
  text.textContent = message || "Processing...";
  overlay.classList.remove("hidden");
}

function hideLoading() {
  const overlay = document.getElementById("global-loading");
  if (!overlay) return;
  overlay.classList.add("hidden");
}

function setErrorBox(id, message) {
  const box = document.getElementById(id);
  if (!box) return;
  box.textContent = message || "";
  box.classList.toggle("hidden", !message);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function fmtDate(value) {
  if (!value) return "";
  return new Date(value).toLocaleString();
}

const connectionTypeFamilies = {
  database: ["DATABASE_SNOWFLAKE", "DATABASE_ORACLE", "DATABASE_DUCKDB", "DATABASE_DELTA"],
  cloud: ["CLOUD_DELIMITED", "CLOUD_EXCEL"],
  local: ["FILE_DELIMITED", "FILE_EXCEL"],
};

function getConnectionFamily(type) {
  if (connectionTypeFamilies.database.includes(type)) return "database";
  if (connectionTypeFamilies.cloud.includes(type)) return "cloud";
  if (connectionTypeFamilies.local.includes(type)) return "local";
  return "";
}
