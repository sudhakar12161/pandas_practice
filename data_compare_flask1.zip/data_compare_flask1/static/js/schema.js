const schemaState = {
  connections: [],
  schemas: [],
  currentSchemaDef: [],
  form: {
    connection_id: "",
    table_name: "",
    where_condition: "WHERE 1=1",
    file_path: "",
    uploaded_path: "",
  },
};

function currentConnection() {
  return schemaState.connections.find((item) => String(item.id) === String(schemaState.form.connection_id));
}

function renderSchemaPreviewForm() {
  const container = document.getElementById("schema-preview-form");
  const conn = currentConnection();
  const family = conn ? getConnectionFamily(conn.type) : "";
  container.innerHTML = `
    <label>Connection Name
      <select id="schema-connection" class="field">
        <option value="">Select connection</option>
        ${schemaState.connections
          .map(
            (item) =>
              `<option value="${item.id}" ${
                String(schemaState.form.connection_id) === String(item.id) ? "selected" : ""
              }>${escapeHtml(item.name)}</option>`
          )
          .join("")}
      </select>
    </label>
    ${
      family === "database"
        ? `
      <label>Table Name
        <input id="schema-table-name" class="field" type="text" value="${escapeHtml(
          schemaState.form.table_name || `${conn?.database_name || ""}.${conn?.schema_name || ""}`.replace(/\.$/, "")
        )}">
      </label>
      <label>Where Condition
        <input id="schema-where" class="field" type="text" value="${escapeHtml(schemaState.form.where_condition)}">
      </label>
    `
        : ""
    }
    ${
      family === "cloud"
        ? `
      <label>Cloud File Path
        <input id="schema-file-path" class="field" type="text" placeholder="s3://bucket/path/file.csv" value="${escapeHtml(
          schemaState.form.file_path
        )}">
      </label>
    `
        : ""
    }
    ${
      family === "local"
        ? `
      <label>Upload Local File
        <div class="file-input-wrap">
          <label class="btn btn-outline file-pick-btn" for="schema-file-upload">Browse</label>
          <span class="file-picked-name">${
            schemaState.form.uploaded_path ? escapeHtml(schemaState.form.uploaded_path.split(/[\\/]/).pop()) : "No file selected"
          }</span>
          <input id="schema-file-upload" class="file-native" type="file">
        </div>
      </label>
      <div class="small-label upload-note">Uploaded: ${
        schemaState.form.uploaded_path ? escapeHtml(schemaState.form.uploaded_path.split(/[\\/]/).pop()) : "None"
      }</div>
    `
        : ""
    }
    <div class="small-label connection-type-note span-all">Connection Type: ${conn ? escapeHtml(conn.type) : "-"}</div>
  `;

  document.getElementById("schema-connection").addEventListener("change", () => {
    setErrorBox("schema-error", "");
    schemaState.form.connection_id = document.getElementById("schema-connection").value;
    schemaState.form.table_name = "";
    schemaState.form.where_condition = "WHERE 1=1";
    schemaState.form.file_path = "";
    schemaState.form.uploaded_path = "";
    renderSchemaPreviewForm();
  });
  document.getElementById("schema-table-name")?.addEventListener("input", (event) => {
    setErrorBox("schema-error", "");
    schemaState.form.table_name = event.target.value;
  });
  document.getElementById("schema-where")?.addEventListener("input", (event) => {
    setErrorBox("schema-error", "");
    schemaState.form.where_condition = event.target.value;
  });
  document.getElementById("schema-file-path")?.addEventListener("input", (event) => {
    setErrorBox("schema-error", "");
    schemaState.form.file_path = event.target.value;
  });

  document.getElementById("schema-file-upload")?.addEventListener("change", async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    try {
      setErrorBox("schema-error", "");
      showLoading("Uploading file...");
      const response = await apiPost("/api/upload", formData, true);
      schemaState.form.uploaded_path = response.path;
      renderSchemaPreviewForm();
      showToast("File uploaded", "success");
    } catch (error) {
      setErrorBox("schema-error", error.message);
      showToast(error.message, "error");
    } finally {
      hideLoading();
    }
  });
}

function renderSchemaList() {
  const body = document.getElementById("schema-list-body");
  const search = document.getElementById("schema-search").value.toLowerCase();
  const rows = schemaState.schemas.filter((item) => !search || item.schema_name.toLowerCase().includes(search));
  body.innerHTML = rows
    .map(
      (item) => `
      <tr>
        <td>${escapeHtml(item.schema_name)}</td>
        <td>${fmtDate(item.created_at)}</td>
        <td><button class="btn btn-danger btn-small" data-schema-id="${item.id}">Delete</button></td>
      </tr>
    `
    )
    .join("");

  body.querySelectorAll("button[data-schema-id]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await apiDelete(`/api/schemas/${btn.getAttribute("data-schema-id")}`);
        showToast("Schema deleted", "success");
        await refreshSchemas();
      } catch (error) {
        showToast(error.message, "error");
      }
    });
  });
}

async function refreshSchemas() {
  const response = await apiGet("/api/schemas");
  schemaState.schemas = response.items;
  renderSchemaList();
}

function openSchemaModal(schemaDef) {
  schemaState.currentSchemaDef = schemaDef;
  const pretty = JSON.stringify(schemaDef, null, 2);
  document.getElementById("schema-json-editor").value = pretty;
  document.getElementById("schema-json-pretty").textContent = pretty;
  document.getElementById("schema-modal").classList.remove("hidden");
}

function closeSchemaModal() {
  document.getElementById("schema-modal").classList.add("hidden");
}

document.getElementById("btn-display-schema").addEventListener("click", async () => {
  try {
    setErrorBox("schema-error", "");
    const connId = document.getElementById("schema-connection").value;
    if (!connId) {
      throw new Error("Select connection first.");
    }
    showLoading("Inferring schema...");
    const payload = {
      connection_id: connId,
      table_name: schemaState.form.table_name,
      where_condition: schemaState.form.where_condition.replace(/^where\s+/i, ""),
      file_path: schemaState.form.file_path,
      uploaded_path: schemaState.form.uploaded_path,
      schema_name: "INFER_SCHEMA",
    };
    const response = await apiPost("/api/schema-preview", payload);
    openSchemaModal(response.schema);
  } catch (error) {
    setErrorBox("schema-error", error.message);
    showToast(error.message, "error");
  } finally {
    hideLoading();
  }
});

document.getElementById("btn-close-schema").addEventListener("click", closeSchemaModal);

document.getElementById("btn-save-schema").addEventListener("click", async () => {
  try {
    setErrorBox("schema-error", "");
    showLoading("Saving schema...");
    const schemaName = document.getElementById("schema-save-name").value.trim();
    const parsed = JSON.parse(document.getElementById("schema-json-editor").value);
    await apiPost("/api/schemas", { schema_name: schemaName, schema_def: parsed });
    showToast("Schema saved", "success");
    closeSchemaModal();
    await refreshSchemas();
  } catch (error) {
    setErrorBox("schema-error", error.message);
    showToast(`Save failed: ${error.message}`, "error");
  } finally {
    hideLoading();
  }
});

document.getElementById("schema-json-editor").addEventListener("input", () => {
  const text = document.getElementById("schema-json-editor").value;
  try {
    const parsed = JSON.parse(text);
    document.getElementById("schema-json-pretty").textContent = JSON.stringify(parsed, null, 2);
  } catch {
    document.getElementById("schema-json-pretty").textContent = text;
  }
});

document.getElementById("btn-copy-schema").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(document.getElementById("schema-json-editor").value);
    showToast("Schema JSON copied", "success");
  } catch (error) {
    showToast(`Copy failed: ${error.message}`, "error");
  }
});

document.getElementById("schema-search").addEventListener("input", renderSchemaList);

async function initializeSchemaPage() {
  try {
    setErrorBox("schema-error", "");
    const [connectionsResponse] = await Promise.all([apiGet("/api/connections"), refreshSchemas()]);
    schemaState.connections = connectionsResponse.items;
    renderSchemaPreviewForm();
  } catch (error) {
    setErrorBox("schema-error", error.message);
    showToast(error.message, "error");
  }
}

initializeSchemaPage();
