const state = {
  connections: [],
  schemas: [],
  source: defaultSideState(),
  target: defaultSideState(),
};

function defaultSideState() {
  return {
    connection_id: "",
    table_name: "",
    where_condition: "WHERE 1=1",
    file_path: "",
    uploaded_path: "",
    uploaded_name: "",
    schema_name: "NONE",
    schema_def: {},
    exclude_columns: [],
    pk_columns: [],
  };
}

function clearResultPanels() {
  document.getElementById("schema-compare-section").classList.add("hidden");
  document.getElementById("analysis-section").classList.add("hidden");
  document.getElementById("report-section").classList.add("hidden");
  setErrorBox("data-compare-error", "");
}

function clearResultPanelsExcept(panelId) {
  ["schema-compare-section", "analysis-section", "report-section"].forEach((id) => {
    if (id !== panelId) document.getElementById(id).classList.add("hidden");
  });
  setErrorBox("data-compare-error", "");
}

function getConnectionById(connId) {
  return state.connections.find((conn) => String(conn.id) === String(connId));
}

function cleanWhereCondition(input) {
  if (!input) return "";
  return input.replace(/^where\s+/i, "").trim();
}

function getSchemaOptions() {
  const options = [`<option value="NONE">None</option>`, `<option value="INFER_SCHEMA">Infer Schema</option>`];
  for (const item of state.schemas) {
    options.push(`<option value="${escapeHtml(item.schema_name)}">${escapeHtml(item.schema_name)}</option>`);
  }
  return options.join("");
}

function renderMultiSelect(sideKey, fieldName) {
  const side = state[sideKey];
  const columns = Object.keys(side.schema_def || {});
  if (!columns.length) {
    return `<div class="hint">Load schema first</div>`;
  }
  const controlId = `${sideKey}-${fieldName}`;
  const placeholder = "Select values";
  const selected = side[fieldName] || [];

  const tagsHtml = selected.length
    ? selected
        .map(
          (value) => `
          <span class="tagbox-pill" data-tagbox-remove="${controlId}" data-value="${escapeHtml(value)}">
            ${escapeHtml(value)} <button type="button" class="tagbox-pill-x" data-tagbox-remove="${controlId}" data-value="${escapeHtml(value)}">x</button>
          </span>
        `
        )
        .join("")
    : `<span class="tagbox-placeholder">${placeholder}</span>`;

  return `
    <div class="tagbox-wrap" id="${controlId}-wrap">
      <button type="button" class="field tagbox-trigger" id="${controlId}-trigger" aria-expanded="false">
        <span id="${controlId}-tags" class="tagbox-tags">${tagsHtml}</span>
        <span class="tagbox-caret">v</span>
      </button>
      <div class="tagbox-menu hidden" id="${controlId}-menu">
        ${columns
          .map((columnName) => {
            const selectedClass = selected.includes(columnName) ? "selected" : "";
            return `
              <button type="button" class="tagbox-option ${selectedClass}" data-tagbox-option="${controlId}" data-value="${escapeHtml(columnName)}">
                ${escapeHtml(columnName)}
              </button>
            `;
          })
          .join("")}
      </div>
    </div>
  `;
}

function renderSideForm(sideKey) {
  const side = state[sideKey];
  const conn = getConnectionById(side.connection_id);
  const connType = conn?.type || "";
  const family = getConnectionFamily(connType);
  const container = document.getElementById(`${sideKey}-form`);

  container.innerHTML = `
    <label>Connection Name
      <select class="field" id="${sideKey}-connection-id">
        <option value="">Select connection</option>
        ${state.connections
          .map(
            (item) =>
              `<option value="${item.id}" ${String(side.connection_id) === String(item.id) ? "selected" : ""}>${escapeHtml(
                item.name
              )}</option>`
          )
          .join("")}
      </select>
    </label>
    <div class="small-label">Connection Type: ${conn ? escapeHtml(conn.type) : "-"}</div>
    ${
      family === "database"
        ? `
        <label>Table Name
          <input id="${sideKey}-table-name" class="field" type="text" value="${escapeHtml(
            side.table_name || `${conn?.database_name || ""}.${conn?.schema_name || ""}`.replace(/\.$/, "")
          )}">
        </label>
        <label>Where Condition
          <input id="${sideKey}-where-condition" class="field" type="text" value="${escapeHtml(side.where_condition)}">
        </label>
      `
        : ""
    }
    ${
      family === "cloud"
        ? `
        <label>Browse File (Cloud Path)
          <input id="${sideKey}-file-path" class="field" type="text" value="${escapeHtml(side.file_path)}" placeholder="s3://bucket/path/file.csv">
        </label>
      `
        : ""
    }
    ${
      family === "local"
        ? `
        <label>Upload Local File
          <div class="file-input-wrap">
            <label class="btn btn-outline file-pick-btn" for="${sideKey}-file-upload">Browse</label>
            <span class="file-picked-name">${side.uploaded_path ? escapeHtml(side.uploaded_path.split(/[\\/]/).pop()) : "No file selected"}</span>
            <input id="${sideKey}-file-upload" class="file-native" type="file">
          </div>
        </label>
        <div class="small-label upload-note">Uploaded: ${side.uploaded_path ? escapeHtml(side.uploaded_path.split(/[\\/]/).pop()) : "None"}</div>
      `
        : ""
    }
    <label>Schema Name
      <select class="field" id="${sideKey}-schema-name">${getSchemaOptions()}</select>
    </label>
    <details>
      <summary>Schema Definition (JSON)</summary>
      <pre class="json-snippet"><code class="language-json">${escapeHtml(JSON.stringify(side.schema_def, null, 2))}</code></pre>
    </details>
    <label>Exclude Columns</label>
    ${renderMultiSelect(sideKey, "exclude_columns")}
    <label>Primary Key Columns</label>
    ${renderMultiSelect(sideKey, "pk_columns")}
  `;

  document.getElementById(`${sideKey}-schema-name`).value = side.schema_name;
  wireSideEvents(sideKey, family);
}

function readSideFromDom(sideKey) {
  const side = state[sideKey];
  side.connection_id = document.getElementById(`${sideKey}-connection-id`)?.value || "";
  side.table_name = document.getElementById(`${sideKey}-table-name`)?.value || "";
  side.where_condition = document.getElementById(`${sideKey}-where-condition`)?.value || "WHERE 1=1";
  side.file_path = document.getElementById(`${sideKey}-file-path`)?.value || "";
  side.schema_name = document.getElementById(`${sideKey}-schema-name`)?.value || "NONE";
}

function resetDownstream(sideKey) {
  const side = state[sideKey];
  side.table_name = "";
  side.where_condition = "WHERE 1=1";
  side.file_path = "";
  side.uploaded_path = "";
  side.uploaded_name = "";
  side.schema_name = "NONE";
  side.schema_def = {};
  side.exclude_columns = [];
  side.pk_columns = [];
}

async function loadSchemaForSide(sideKey) {
  const side = state[sideKey];
  if (!side.connection_id) return;

  const payload = {
    connection_id: side.connection_id,
    table_name: side.table_name,
    where_condition: cleanWhereCondition(side.where_condition),
    file_path: side.file_path,
    uploaded_path: side.uploaded_path,
    uploaded_name: side.uploaded_name,
    schema_name: side.schema_name,
  };
  const response = await apiPost("/api/schema-preview", payload);
  side.schema_def = response.schema;
  side.exclude_columns = [];
  side.pk_columns = [];
  renderSideForm(sideKey);
}

function wireSideEvents(sideKey, family) {
  document.getElementById(`${sideKey}-connection-id`)?.addEventListener("change", () => {
    readSideFromDom(sideKey);
    resetDownstream(sideKey);
    renderSideForm(sideKey);
    clearResultPanels();
  });

  document.getElementById(`${sideKey}-table-name`)?.addEventListener("input", () => {
    readSideFromDom(sideKey);
    state[sideKey].schema_def = {};
    state[sideKey].exclude_columns = [];
    state[sideKey].pk_columns = [];
    renderSideForm(sideKey);
    clearResultPanels();
  });

  document.getElementById(`${sideKey}-file-path`)?.addEventListener("input", () => {
    readSideFromDom(sideKey);
    state[sideKey].schema_def = {};
    state[sideKey].exclude_columns = [];
    state[sideKey].pk_columns = [];
    renderSideForm(sideKey);
    clearResultPanels();
  });

  document.getElementById(`${sideKey}-where-condition`)?.addEventListener("input", () => {
    readSideFromDom(sideKey);
    clearResultPanels();
  });

  document.getElementById(`${sideKey}-schema-name`)?.addEventListener("change", async () => {
    readSideFromDom(sideKey);
    clearResultPanels();
    try {
      showLoading("Loading schema...");
      await loadSchemaForSide(sideKey);
    } catch (error) {
      setErrorBox("data-compare-error", error.message);
      showToast(error.message, "error");
    } finally {
      hideLoading();
    }
  });

  setupTagBox(sideKey, "exclude_columns");
  setupTagBox(sideKey, "pk_columns");

  if (family === "local") {
    document.getElementById(`${sideKey}-file-upload`)?.addEventListener("change", async (event) => {
      const file = event.target.files[0];
      if (!file) return;
      const formData = new FormData();
      formData.append("file", file);
      try {
        showLoading("Uploading file...");
        const response = await apiPost("/api/upload", formData, true);
        state[sideKey].uploaded_path = response.path;
        state[sideKey].uploaded_name = response.uploaded_name || "";
        state[sideKey].schema_def = {};
        state[sideKey].exclude_columns = [];
        state[sideKey].pk_columns = [];
        renderSideForm(sideKey);
        clearResultPanels();
        showToast(`${sideKey} file uploaded`, "success");
      } catch (error) {
        setErrorBox("data-compare-error", error.message);
        showToast(error.message, "error");
      } finally {
        hideLoading();
      }
    });
  }
}

function setupTagBox(sideKey, fieldName) {
  const controlId = `${sideKey}-${fieldName}`;
  const trigger = document.getElementById(`${controlId}-trigger`);
  const menu = document.getElementById(`${controlId}-menu`);
  const tags = document.getElementById(`${controlId}-tags`);
  if (!trigger || !menu) return;

  trigger.addEventListener("click", (event) => {
    event.stopPropagation();
    document.querySelectorAll(".tagbox-menu").forEach((node) => {
      if (node !== menu) node.classList.add("hidden");
    });
    menu.classList.toggle("hidden");
    trigger.setAttribute("aria-expanded", String(!menu.classList.contains("hidden")));
  });

  menu.addEventListener("click", (event) => {
    event.stopPropagation();
    const option = event.target.closest(`[data-tagbox-option="${controlId}"]`);
    if (!option) return;
    const value = option.getAttribute("data-value");
    if (!value) return;
    toggleTagBoxValue(sideKey, fieldName, value);
    renderTagBoxVisuals(controlId, state[sideKey][fieldName], tags, menu);
  });

  tags.addEventListener("click", (event) => {
    const removeBtn = event.target.closest(`[data-tagbox-remove="${controlId}"]`);
    if (!removeBtn) return;
    event.preventDefault();
    event.stopPropagation();
    const value = removeBtn.getAttribute("data-value");
    if (!value) return;
    toggleTagBoxValue(sideKey, fieldName, value, true);
    renderTagBoxVisuals(controlId, state[sideKey][fieldName], tags, menu);
  });

  renderTagBoxVisuals(controlId, state[sideKey][fieldName], tags, menu);
}

document.addEventListener("click", () => {
  document.querySelectorAll(".tagbox-menu").forEach((node) => node.classList.add("hidden"));
  document.querySelectorAll(".tagbox-trigger").forEach((node) => node.setAttribute("aria-expanded", "false"));
});

function toggleTagBoxValue(sideKey, fieldName, value, forceRemove = false) {
  const current = state[sideKey][fieldName] || [];
  const exists = current.includes(value);
  if (exists || forceRemove) {
    state[sideKey][fieldName] = current.filter((item) => item !== value);
  } else {
    state[sideKey][fieldName] = [...current, value];
  }
}

function renderTagBoxVisuals(controlId, selectedValues, tagsNode, menuNode) {
  const selected = selectedValues || [];
  tagsNode.innerHTML = selected.length
    ? selected
        .map(
          (value) => `
            <span class="tagbox-pill" data-tagbox-remove="${controlId}" data-value="${escapeHtml(value)}">
              ${escapeHtml(value)} <button type="button" class="tagbox-pill-x" data-tagbox-remove="${controlId}" data-value="${escapeHtml(value)}">x</button>
            </span>
          `
        )
        .join("")
    : `<span class="tagbox-placeholder">Select values</span>`;

  menuNode.querySelectorAll(`[data-tagbox-option="${controlId}"]`).forEach((node) => {
    const value = node.getAttribute("data-value");
    const isSelected = value && selected.includes(value);
    node.classList.toggle("selected", Boolean(isSelected));
  });
}

function gatherComparePayload() {
  readSideFromDom("source");
  readSideFromDom("target");
  const sourcePk = state.source.pk_columns || [];
  const targetPk = state.target.pk_columns || [];
  return {
    source: { ...state.source, where_condition: cleanWhereCondition(state.source.where_condition) },
    target: { ...state.target, where_condition: cleanWhereCondition(state.target.where_condition) },
    exclude_columns: Array.from(new Set([...state.source.exclude_columns, ...state.target.exclude_columns])),
    pk_columns: sourcePk.length ? sourcePk : targetPk,
    source_pk_columns: sourcePk,
    target_pk_columns: targetPk,
  };
}

function renderSchemaCompare(rows) {
  const body = document.getElementById("schema-compare-body");
  body.innerHTML = rows
    .map(
      (row) => `
      <tr class="${row.match ? "row-match" : "row-mismatch"}">
        <td>${escapeHtml(row.source_column || "-")}</td>
        <td>${escapeHtml(row.source_type || "-")}</td>
        <td>${escapeHtml(row.target_column || "-")}</td>
        <td>${escapeHtml(row.target_type || "-")}</td>
        <td>${row.match ? "MATCH" : "MISMATCH"}</td>
      </tr>
    `
    )
    .join("");
  document.getElementById("schema-compare-section").classList.remove("hidden");
}

function normalizeName(name) {
  return String(name || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function scoreNameSimilarity(a, b) {
  const x = normalizeName(a);
  const y = normalizeName(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  if (x.includes(y) || y.includes(x)) return 0.8;
  const xSet = new Set(x);
  const ySet = new Set(y);
  const overlap = [...xSet].filter((c) => ySet.has(c)).length;
  return overlap / Math.max(xSet.size, ySet.size);
}

function bestFuzzyTarget(sourceColumn, targetColumns) {
  let bestName = "";
  let bestScore = 0;
  for (const target of targetColumns) {
    const score = scoreNameSimilarity(sourceColumn, target);
    if (score > bestScore) {
      bestScore = score;
      bestName = target;
    }
  }
  return bestScore >= 0.45 ? bestName : "";
}

function openMappingModal(sourceSchema, targetSchema, pkColumns) {
  const sourceColumns = Object.keys(sourceSchema || {});
  const targetColumns = Object.keys(targetSchema || {});
  const form = document.getElementById("mapping-form");
  const rowsHtml = sourceColumns
    .map((sourceCol) => {
      const exact = targetColumns.includes(sourceCol) ? sourceCol : "";
      const fuzzy = exact || bestFuzzyTarget(sourceCol, targetColumns);
      const rowClass = fuzzy ? "mapping-row" : "mapping-row mapping-row-missing";
      return `
        <tr class="${rowClass}" data-mapping-row="${escapeHtml(sourceCol)}">
          <td class="mapping-source-cell">${escapeHtml(sourceCol)} ${pkColumns.includes(sourceCol) ? "(PK)" : ""}</td>
          <td class="mapping-target-cell">
            <select class="field mapping-select" data-source-col="${escapeHtml(sourceCol)}">
              ${pkColumns.includes(sourceCol) ? "" : '<option value="">--Skip--</option>'}
              ${targetColumns
                .map((col) => `<option value="${escapeHtml(col)}" ${col === fuzzy ? "selected" : ""}>${escapeHtml(col)}</option>`)
                .join("")}
            </select>
          </td>
        </tr>
      `;
    })
    .join("");
  form.innerHTML = `
    <table class="mapping-table">
      <thead>
        <tr>
          <th>Source Column</th>
          <th>Target Column</th>
        </tr>
      </thead>
      <tbody>
        ${rowsHtml}
      </tbody>
    </table>
  `;

  form.querySelectorAll(".mapping-select").forEach((select) => {
    select.addEventListener("change", () => updateMappingWarnings());
  });
  updateMappingWarnings();
  document.getElementById("mapping-modal").classList.remove("hidden");
}

function closeMappingModal() {
  document.getElementById("mapping-modal").classList.add("hidden");
  const warning = document.getElementById("mapping-warning");
  if (warning) {
    warning.textContent = "";
    warning.classList.add("hidden");
  }
}

function collectMapping() {
  const mapping = {};
  const missingPk = [];
  document.querySelectorAll(".mapping-select").forEach((select) => {
    const sourceCol = select.getAttribute("data-source-col");
    const isPk = (select.parentElement?.textContent || "").includes("(PK)");
    if (sourceCol && select.value) {
      mapping[sourceCol] = select.value;
    } else if (sourceCol && isPk) {
      missingPk.push(sourceCol);
    }
  });
  return { mapping, missingPk };
}

function updateMappingWarnings() {
  const warning = document.getElementById("mapping-warning");
  const selects = Array.from(document.querySelectorAll(".mapping-select"));
  const selectedTargets = selects.map((s) => s.value).filter(Boolean);
  const counts = {};
  selectedTargets.forEach((v) => {
    counts[v] = (counts[v] || 0) + 1;
  });
  const duplicates = Object.entries(counts)
    .filter(([, count]) => count > 1)
    .map(([name]) => name);

  selects.forEach((select) => {
    const row = select.closest(".mapping-row");
    if (!row) return;
    row.classList.toggle("mapping-row-missing", !select.value);
  });

  if (duplicates.length) {
    warning.textContent = `Warning: Same target column mapped multiple times: ${duplicates.join(", ")}`;
    warning.classList.remove("hidden");
  } else {
    warning.textContent = "";
    warning.classList.add("hidden");
  }
}

function renderAnalysisTable(prefix, stats) {
  const head = document.getElementById(`${prefix}-analysis-head`);
  const body = document.getElementById(`${prefix}-analysis-body`);
  document.getElementById(`${prefix}-analysis-title`).textContent = `${stats.dataset_name} Data Statistics`;

  head.innerHTML = `
    <tr>
      <th>METRIC</th>
      ${stats.columns.map((col) => `<th>${escapeHtml(col)}</th>`).join("")}
    </tr>
  `;
  body.innerHTML = stats.rows
    .map(
      (row) => `
      <tr>
        <td>${escapeHtml(row.metric)}</td>
        ${stats.columns.map((col) => `<td>${escapeHtml(row.values[col] ?? "")}</td>`).join("")}
      </tr>
    `
    )
    .join("");
}

function renderCompareSummary(report) {
  const wrap = document.getElementById("compare-summary-tiles");
  const sourceTiles = [
    { metric: "TOTAL_ROWS", value: report.source.total_rows },
    { metric: "UNIQUE_ROWS_BY_PK", value: report.source.unique_rows_by_pk },
    { metric: "DUPLICATE_ROWS_BY_PK", value: report.source.duplicate_rows_by_pk },
    { metric: "ROWS_ONLY_IN_SOURCE", value: report.source.rows_only_in_source },
  ];
  const targetTiles = [
    { metric: "TOTAL_ROWS", value: report.target.total_rows },
    { metric: "UNIQUE_ROWS_BY_PK", value: report.target.unique_rows_by_pk },
    { metric: "DUPLICATE_ROWS_BY_PK", value: report.target.duplicate_rows_by_pk },
    { metric: "ROWS_ONLY_IN_TARGET", value: report.target.rows_only_in_target },
  ];
  const commonTiles = [
    { metric: "MATCHED_ROWS_BY_PK", value: report.common.matched_rows_by_pk },
    { metric: "NOT_MATCHED_ROWS_BY_PK", value: report.common.not_matched_rows_by_pk },
    { metric: "MISMATCHED_COLUMNS", value: report.common.mismatched_columns || "-" },
  ];

  const renderRow = (title, rowClass, tiles) => `
    <div class="tile-row-wrap ${rowClass}">
      <div class="tile-row-title">${escapeHtml(title)}</div>
      <div class="tile-row">
        ${tiles
          .map(
            (tile) => `
            <div class="tile ${rowClass}">
              <h4>${escapeHtml(tile.metric)}</h4>
              <p>${escapeHtml(tile.value)}</p>
            </div>
          `
          )
          .join("")}
      </div>
    </div>
  `;

  wrap.innerHTML =
    renderRow(report.source.dataset_name, "summary-row-source", sourceTiles) +
    renderRow(report.target.dataset_name, "summary-row-target", targetTiles) +
    renderRow("COMMON", "summary-row-common", commonTiles);
}

async function waitForJob(jobId, loadingText) {
  while (true) {
    showLoading(loadingText || "Processing...");
    const response = await apiGet(`/api/jobs/${jobId}`);
    const job = response.job;
    if (job.status === "completed") return job.result;
    if (job.status === "failed") throw new Error(job.error || "Job failed");
    await new Promise((resolve) => setTimeout(resolve, 1200));
  }
}

async function initializePage() {
  try {
    const [connResponse, schemaResponse] = await Promise.all([apiGet("/api/connections"), apiGet("/api/schemas")]);
    state.connections = connResponse.items;
    state.schemas = schemaResponse.items;
    renderSideForm("source");
    renderSideForm("target");
  } catch (error) {
    setErrorBox("data-compare-error", error.message);
    showToast(error.message, "error");
  }
}

document.getElementById("btn-compare-schema").addEventListener("click", async () => {
  try {
    clearResultPanelsExcept("schema-compare-section");
    showLoading("Comparing schema...");
    const payload = gatherComparePayload();
    const response = await apiPost("/api/compare/schema", payload);
    renderSchemaCompare(response.rows);
    showToast("Schema comparison completed", "success");
  } catch (error) {
    setErrorBox("data-compare-error", error.message);
    showToast(error.message, "error");
  } finally {
    hideLoading();
  }
});

document.getElementById("btn-analyze-data").addEventListener("click", async () => {
  try {
    clearResultPanelsExcept("analysis-section");
    showLoading("Analyzing source and target data...");
    const payload = gatherComparePayload();
    if (!payload.pk_columns.length) {
      throw new Error("Please select Primary Key Columns before Analyze Data.");
    }
    const start = await apiPost("/api/jobs/analyze", payload);
    const response = await waitForJob(start.job_id, "Analyzing source and target data...");
    renderAnalysisTable("source", response.source_metrics);
    renderAnalysisTable("target", response.target_metrics);
    document.getElementById("analysis-section").classList.remove("hidden");
    if (response.excel_path) {
      const fileName = response.excel_path.split(/[\\/]/).pop();
      const link = document.getElementById("analysis-download");
      link.href = `/api/exports/${fileName}`;
      link.classList.remove("hidden");
    }
    showToast("Data analysis completed", "success");
  } catch (error) {
    setErrorBox("data-compare-error", error.message);
    showToast(error.message, "error");
  } finally {
    hideLoading();
  }
});

document.getElementById("btn-compare-data").addEventListener("click", async () => {
  try {
    clearResultPanelsExcept("report-section");
    showLoading("Preparing column mapping...");
    const payload = gatherComparePayload();
    if (!payload.source.schema_name || payload.source.schema_name === "NONE" || !payload.target.schema_name || payload.target.schema_name === "NONE") {
      throw new Error("Select Schema Name for both Source and Target before Compare Data.");
    }
    if (!payload.source_pk_columns.length || !payload.target_pk_columns.length) {
      throw new Error("Please select Primary Key Columns on both Source and Target before Compare Data.");
    }
    if (payload.source_pk_columns.length !== payload.target_pk_columns.length) {
      throw new Error("Source and Target PK column counts must match before Compare Data.");
    }
    const schemaResponse = await apiPost("/api/compare/schema", payload);
    openMappingModal(schemaResponse.source_schema, schemaResponse.target_schema, payload.source_pk_columns);
  } catch (error) {
    setErrorBox("data-compare-error", error.message);
    showToast(error.message, "error");
  } finally {
    hideLoading();
  }
});

document.getElementById("btn-close-mapping").addEventListener("click", closeMappingModal);

document.getElementById("btn-confirm-mapping").addEventListener("click", async () => {
  try {
    showLoading("Comparing mapped data...");
    const payload = gatherComparePayload();
    if (payload.source_pk_columns.length !== payload.target_pk_columns.length) {
      throw new Error("Source and Target PK column counts must match before Compare Data.");
    }
    const { mapping, missingPk } = collectMapping();
    payload.column_mapping = mapping;
    if (missingPk.length) {
      throw new Error(`Please map all PK columns: ${missingPk.join(", ")}`);
    }
    const mappedTargetPks = payload.source_pk_columns.map((col) => mapping[col]).filter(Boolean);
    const uniqueMappedTargetPks = [...new Set(mappedTargetPks)];
    if (uniqueMappedTargetPks.length !== payload.target_pk_columns.length) {
      throw new Error("Mapped target PK columns must uniquely match all selected target PK columns.");
    }
    const missingTargetPk = payload.target_pk_columns.filter((pk) => !uniqueMappedTargetPks.includes(pk));
    if (missingTargetPk.length) {
      throw new Error(`Missing mapping for target PK columns: ${missingTargetPk.join(", ")}`);
    }
    if (!Object.keys(payload.column_mapping).length) {
      throw new Error("Please map at least one column.");
    }
    const start = await apiPost("/api/jobs/compare-data", payload);
    const response = await waitForJob(start.job_id, "Comparing mapped data...");
    renderCompareSummary(response.report);
    document.getElementById("report-section").classList.remove("hidden");
    if (response.report.excel_path) {
      const fileName = response.report.excel_path.split(/[\\/]/).pop();
      const link = document.getElementById("report-download");
      link.href = `/api/exports/${fileName}`;
      link.classList.remove("hidden");
    }
    closeMappingModal();
    showToast("Data compare completed", "success");
  } catch (error) {
    setErrorBox("data-compare-error", error.message);
    showToast(error.message, "error");
  } finally {
    hideLoading();
  }
});

initializePage();
