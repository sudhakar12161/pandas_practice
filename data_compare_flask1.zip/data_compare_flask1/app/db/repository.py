from __future__ import annotations

import json
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable

import duckdb


class DuckDbRepository:
    """Small repository around DuckDB metadata storage."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._initialize()

    @contextmanager
    def connection(self):
        conn = duckdb.connect(str(self.db_path))
        try:
            yield conn
        finally:
            conn.close()

    def _initialize(self) -> None:
        with self.connection() as conn:
            conn.execute("CREATE SEQUENCE IF NOT EXISTS CONN_ID_SEQ START 1;")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS CONNECTIONS (
                  ID INTEGER PRIMARY KEY DEFAULT nextval('CONN_ID_SEQ'),
                  NAME TEXT,
                  TYPE TEXT,
                  HOSTNAME TEXT,
                  USERNAME TEXT,
                  PASSWORD TEXT,
                  PORT INTEGER,
                  DATABASE_NAME TEXT,
                  SCHEMA_NAME TEXT,
                  AUTHTYPE TEXT,
                  HEADER BOOLEAN,
                  FIELD_DELIM TEXT,
                  TRIM_SPACE BOOLEAN,
                  FIELD_ENCLOSED_BY TEXT,
                  CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                """
            )
            conn.execute("CREATE SEQUENCE IF NOT EXISTS SCHEMA_ID_SEQ START 1;")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS SCHEMAS (
                  ID INTEGER PRIMARY KEY DEFAULT nextval('SCHEMA_ID_SEQ'),
                  SCHEMA_NAME TEXT,
                  SCHEMA_DEF JSON,
                  CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                """
            )

    def fetch_all(self, query: str, params: Iterable[Any] | None = None) -> list[dict[str, Any]]:
        with self.connection() as conn:
            rows = conn.execute(query, params or []).fetchall()
            columns = [item[0] for item in conn.description]
            results: list[dict[str, Any]] = []
            for row in rows:
                item = {}
                for idx, value in enumerate(row):
                    key = columns[idx].lower()
                    if key == "schema_def" and isinstance(value, str):
                        item[key] = json.loads(value)
                    else:
                        item[key] = value
                results.append(item)
            return results

    def fetch_one(self, query: str, params: Iterable[Any] | None = None) -> dict[str, Any] | None:
        rows = self.fetch_all(query, params)
        return rows[0] if rows else None

    def execute(self, query: str, params: Iterable[Any] | None = None) -> None:
        with self.connection() as conn:
            conn.execute(query, params or [])

