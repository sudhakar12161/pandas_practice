from __future__ import annotations

from flask import Flask

from app.config import Config
from app.db.repository import DuckDbRepository
from app.routes.api import api_bp
from app.routes.pages import pages_bp
from app.services.compare_service import CompareService
from app.services.connection_service import ConnectionService
from app.services.datasource_loader import DataSourceLoader
from app.services.job_service import JobService
from app.services.schema_service import SchemaService
from app.services.spark_session import SparkSessionManager


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder=str(Config.BASE_DIR / "templates"),
        static_folder=str(Config.BASE_DIR / "static"),
    )
    app.config.from_object(Config)

    app.config["UPLOAD_DIR"].mkdir(parents=True, exist_ok=True)
    app.config["EXPORT_DIR"].mkdir(parents=True, exist_ok=True)

    repository = DuckDbRepository(app.config["DB_PATH"])
    connection_service = ConnectionService(repository)
    schema_service = SchemaService(repository)
    spark_manager = SparkSessionManager(app.config["SPARK_APP_NAME"], app.config["SPARK_SESSION_TTL_SECONDS"])
    job_service = JobService(app.config["JOB_MAX_WORKERS"])

    class LazyLoader:
        def __init__(self) -> None:
            self._active_app_id: str | None = None
            self._active_loader: DataSourceLoader | None = None

        def _loader(self) -> DataSourceLoader:
            spark = spark_manager.get_session()
            app_id = spark.sparkContext.applicationId
            if self._active_loader is None or self._active_app_id != app_id:
                self._active_loader = DataSourceLoader(
                    spark=spark,
                    schema_cache_ttl_seconds=app.config["SCHEMA_CACHE_TTL_SECONDS"],
                    sample_ratio_small=app.config["SCHEMA_SAMPLING_RATIO_SMALL"],
                    sample_ratio_medium=app.config["SCHEMA_SAMPLING_RATIO_MEDIUM"],
                    sample_ratio_large=app.config["SCHEMA_SAMPLING_RATIO_LARGE"],
                )
                self._active_app_id = app_id
            return self._active_loader

        def load_dataframe(self, side):
            return self._loader().load_dataframe(side)

        def infer_schema(self, side):
            return self._loader().infer_schema(side)

    compare_service = CompareService(
        LazyLoader(),
        app.config["EXPORT_DIR"],
        app.config["MAX_COMPARE_ERROR_ROWS"],
        app.config["COMPARE_REPARTITION_THRESHOLD"],
    )

    app.config["services"] = {
        "connections": connection_service,
        "schemas": schema_service,
        "compare": compare_service,
        "jobs": job_service,
    }

    app.register_blueprint(pages_bp)
    app.register_blueprint(api_bp)
    return app
