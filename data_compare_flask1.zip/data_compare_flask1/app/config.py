from __future__ import annotations

import os
from pathlib import Path


class Config:
    """Application configuration with sensible local defaults."""

    BASE_DIR = Path(__file__).resolve().parent.parent
    DB_PATH = BASE_DIR / "app_meta.duckdb"
    UPLOAD_DIR = BASE_DIR / "uploads"
    EXPORT_DIR = BASE_DIR / "exports"
    LOG_DIR = BASE_DIR / "logs"
    SPARK_APP_NAME = "data-compare-flask"
    SPARK_SESSION_TTL_SECONDS = 30 * 60
    MAX_COMPARE_ERROR_ROWS = 10_000
    COMPARE_REPARTITION_THRESHOLD = 500_000
    JOB_MAX_WORKERS = 2
    SCHEMA_CACHE_TTL_SECONDS = 900
    SCHEMA_SAMPLING_RATIO_SMALL = 0.25
    SCHEMA_SAMPLING_RATIO_MEDIUM = 0.10
    SCHEMA_SAMPLING_RATIO_LARGE = 0.03
    # PySpark partition tuning by dataset size
    SPARK_SMALL_FILE_MB = 64
    SPARK_LARGE_FILE_MB = 512
    SPARK_SMALL_FILE_PARTITIONS = 2
    SPARK_LARGE_FILE_PARTITION_MULTIPLIER = 2
    # Snowflake Spark connector settings.
    # You can override these with environment variables:
    # SNOWFLAKE_SPARK_PACKAGE, SNOWFLAKE_JDBC_PACKAGE, SPARK_EXTRA_JARS
    # Keep Snowflake connector opt-in only.
    # Set these env vars explicitly when you have a connector build compatible
    # with your Spark/Scala runtime.
    SNOWFLAKE_SPARK_PACKAGE = os.getenv("SNOWFLAKE_SPARK_PACKAGE", "")
    SNOWFLAKE_JDBC_PACKAGE = os.getenv("SNOWFLAKE_JDBC_PACKAGE", "")
    SPARK_EXTRA_JARS = os.getenv("SPARK_EXTRA_JARS", "")
