from __future__ import annotations

from pathlib import Path


class Config:
    """Application configuration with sensible local defaults."""

    BASE_DIR = Path(__file__).resolve().parent.parent
    DB_PATH = BASE_DIR / "app_meta.duckdb"
    UPLOAD_DIR = BASE_DIR / "uploads"
    EXPORT_DIR = BASE_DIR / "exports"
    SPARK_APP_NAME = "data-compare-flask"
    SPARK_SESSION_TTL_SECONDS = 30 * 60
    MAX_COMPARE_ERROR_ROWS = 10_000
    COMPARE_REPARTITION_THRESHOLD = 500_000
    JOB_MAX_WORKERS = 2
    SCHEMA_CACHE_TTL_SECONDS = 900
    SCHEMA_SAMPLING_RATIO_SMALL = 0.25
    SCHEMA_SAMPLING_RATIO_MEDIUM = 0.10
    SCHEMA_SAMPLING_RATIO_LARGE = 0.03
