from __future__ import annotations

from pathlib import Path

from app.utils.constants import CLOUD_TYPES, DATABASE_TYPES, FILE_TYPES


def require_fields(payload: dict, fields: list[str]) -> list[str]:
    missing = []
    for field in fields:
        if payload.get(field) in (None, "", []):
            missing.append(field)
    return missing


def validate_connection_payload(payload: dict) -> list[str]:
    errors: list[str] = []
    conn_type = payload.get("type")
    if not conn_type:
        return ["type is required"]

    if not payload.get("name"):
        errors.append("name is required")

    if conn_type in {"FILE_DELIMITED", "CLOUD_DELIMITED"}:
        missing = require_fields(payload, ["header", "field_delim", "trim_space"])
        errors.extend([f"{field} is required" for field in missing])

    if conn_type in {"FILE_EXCEL", "CLOUD_EXCEL"}:
        missing = require_fields(payload, ["header", "trim_space"])
        errors.extend([f"{field} is required" for field in missing])

    if conn_type == "DATABASE_SNOWFLAKE":
        auth_type = payload.get("authtype")
        required = ["username", "hostname", "database_name", "schema_name", "authtype"]
        if auth_type != "externalbrowser":
            required.append("password")
        missing = require_fields(payload, required)
        errors.extend([f"{field} is required" for field in missing])

    if conn_type == "DATABASE_ORACLE":
        missing = require_fields(
            payload,
            ["username", "password", "hostname", "database_name", "schema_name", "port"],
        )
        errors.extend([f"{field} is required" for field in missing])

    if conn_type in {"DATABASE_DUCKDB", "DATABASE_DELTA"}:
        if not payload.get("hostname"):
            errors.append("hostname is required (path to database or delta root)")

    return errors


def validate_side_for_compare(side: dict, side_name: str, require_data_source: bool = True) -> list[str]:
    errors: list[str] = []
    conn = side.get("connection")
    if not conn:
        return [f"{side_name}: connection is required"]

    conn_type = conn.get("type")
    schema_mode = side.get("schema_name")

    if require_data_source and conn_type in DATABASE_TYPES and not side.get("table_name"):
        errors.append(f"{side_name}: table_name is required for database connections")

    if require_data_source and conn_type in FILE_TYPES:
        uploaded_path = side.get("uploaded_path")
        if not uploaded_path or not Path(uploaded_path).exists():
            errors.append(f"{side_name}: local file must be uploaded")

    if require_data_source and conn_type in CLOUD_TYPES and not side.get("file_path"):
        errors.append(f"{side_name}: cloud file path is required")

    if schema_mode == "INFER_SCHEMA":
        needs_source = conn_type in DATABASE_TYPES and not side.get("table_name")
        needs_file = conn_type in (FILE_TYPES | CLOUD_TYPES) and not (
            side.get("uploaded_path") or side.get("file_path")
        )
        if needs_source or needs_file:
            errors.append(
                f"{side_name}: infer schema requires either table name (database) or selected file (file/cloud)"
            )

    return errors
