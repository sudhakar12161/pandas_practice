from __future__ import annotations

CONNECTION_TYPES = {
    "FILE_DELIMITED": "File - Delimited (CSV or TSV)",
    "FILE_EXCEL": "File - Excel",
    "CLOUD_DELIMITED": "Cloud File - Delimited (CSV or TSV)",
    "CLOUD_EXCEL": "Cloud - Excel",
    "DATABASE_SNOWFLAKE": "Database - Snowflake",
    "DATABASE_ORACLE": "Database - Oracle",
    "DATABASE_DUCKDB": "Database - DuckDB",
    "DATABASE_DELTA": "Database - Delta",
}

DATABASE_TYPES = {"DATABASE_SNOWFLAKE", "DATABASE_ORACLE", "DATABASE_DUCKDB", "DATABASE_DELTA"}
FILE_TYPES = {"FILE_DELIMITED", "FILE_EXCEL"}
CLOUD_TYPES = {"CLOUD_DELIMITED", "CLOUD_EXCEL"}

