from __future__ import annotations

from typing import Any


def canonical_dtype(dtype: Any) -> str:
    """Convert source-specific data types to a framework-agnostic type label."""
    d = str(dtype or "").strip().lower()
    if not d:
        return "STRING"
    if any(x in d for x in ["char", "string", "text", "varchar", "nchar", "nvarchar", "clob"]):
        return "STRING"
    if any(x in d for x in ["bigint", "smallint", "tinyint", "int", "number(38", "integer"]):
        return "INT"
    if any(x in d for x in ["decimal", "numeric", "number", "money"]):
        return "DECIMAL"
    if any(x in d for x in ["double", "float", "real"]):
        return "FLOAT"
    if "bool" in d:
        return "BOOLEAN"
    if "timestamp" in d or "datetime" in d:
        return "TIMESTAMP"
    if d == "date" or d.startswith("date"):
        return "DATE"
    if "binary" in d or "blob" in d or "bytea" in d:
        return "BINARY"
    if "array" in d:
        return "ARRAY"
    if "map" in d:
        return "MAP"
    if "struct" in d or "object" in d or "variant" in d:
        return "STRUCT"
    return d.upper()


def normalize_schema_def(schema_def: Any) -> dict[str, str]:
    """Accept map/list schema formats and return ordered {column: canonical_type}."""
    if isinstance(schema_def, dict):
        return {str(k): canonical_dtype(v) for k, v in schema_def.items()}
    if isinstance(schema_def, list):
        normalized: dict[str, str] = {}
        for item in schema_def:
            if isinstance(item, dict) and item.get("name"):
                normalized[str(item["name"])] = canonical_dtype(item.get("type", "string"))
        return normalized
    return {}
