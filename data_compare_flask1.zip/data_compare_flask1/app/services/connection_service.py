from __future__ import annotations

from typing import Any

from app.db.repository import DuckDbRepository
from app.utils.constants import CONNECTION_TYPES
from app.utils.validators import validate_connection_payload


class ConnectionService:
    """CRUD for connection metadata."""

    def __init__(self, repository: DuckDbRepository) -> None:
        self.repository = repository

    def list_connections(self) -> list[dict[str, Any]]:
        return self.repository.fetch_all("SELECT * FROM CONNECTIONS ORDER BY CREATED_AT DESC")

    def get_connection(self, conn_id: int) -> dict[str, Any] | None:
        return self.repository.fetch_one("SELECT * FROM CONNECTIONS WHERE ID = ?", [conn_id])

    def create_connection(self, payload: dict[str, Any]) -> tuple[bool, list[str]]:
        errors = validate_connection_payload(payload)
        if payload.get("type") not in CONNECTION_TYPES:
            errors.append("unsupported connection type")
        if errors:
            return False, errors

        self.repository.execute(
            """
            INSERT INTO CONNECTIONS
            (NAME, TYPE, HOSTNAME, USERNAME, PASSWORD, PORT, DATABASE_NAME, SCHEMA_NAME, AUTHTYPE, HEADER,
             FIELD_DELIM, TRIM_SPACE, FIELD_ENCLOSED_BY)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                payload.get("name"),
                payload.get("type"),
                payload.get("hostname"),
                payload.get("username"),
                payload.get("password"),
                payload.get("port"),
                payload.get("database_name"),
                payload.get("schema_name"),
                payload.get("authtype"),
                payload.get("header"),
                payload.get("field_delim"),
                payload.get("trim_space"),
                payload.get("field_enclosed_by"),
            ],
        )
        return True, []

    def delete_connection(self, conn_id: int) -> None:
        self.repository.execute("DELETE FROM CONNECTIONS WHERE ID = ?", [conn_id])
