from __future__ import annotations

import json
from typing import Any

from app.db.repository import DuckDbRepository


class SchemaService:
    """CRUD for schema definitions."""

    def __init__(self, repository: DuckDbRepository) -> None:
        self.repository = repository

    def list_schemas(self) -> list[dict[str, Any]]:
        rows = self.repository.fetch_all("SELECT * FROM SCHEMAS ORDER BY CREATED_AT DESC")
        for row in rows:
            row["schema_def"] = self._normalize_schema_def(row.get("schema_def"))
        return rows

    def get_schema(self, schema_name: str) -> dict[str, Any] | None:
        row = self.repository.fetch_one("SELECT * FROM SCHEMAS WHERE SCHEMA_NAME = ?", [schema_name])
        if row:
            row["schema_def"] = self._normalize_schema_def(row.get("schema_def"))
        return row

    def create_schema(self, schema_name: str, schema_def: Any) -> tuple[bool, str | None]:
        if not schema_name:
            return False, "schema_name is required"
        if not schema_def:
            return False, "schema_def is required"
        normalized = self._normalize_schema_def(schema_def)
        if not normalized:
            return False, "schema_def format is invalid"

        existing = self.get_schema(schema_name)
        if existing:
            self.repository.execute(
                "UPDATE SCHEMAS SET SCHEMA_DEF = ? WHERE SCHEMA_NAME = ?",
                [json.dumps(normalized), schema_name],
            )
        else:
            self.repository.execute(
                "INSERT INTO SCHEMAS (SCHEMA_NAME, SCHEMA_DEF) VALUES (?, ?)",
                [schema_name, json.dumps(normalized)],
            )
        return True, None

    def delete_schema(self, schema_id: int) -> None:
        self.repository.execute("DELETE FROM SCHEMAS WHERE ID = ?", [schema_id])

    def _normalize_schema_def(self, schema_def: Any) -> dict[str, str]:
        if isinstance(schema_def, dict):
            return {str(k): str(v) for k, v in schema_def.items()}
        if isinstance(schema_def, list):
            normalized: dict[str, str] = {}
            for item in schema_def:
                if isinstance(item, dict) and item.get("name"):
                    normalized[str(item["name"])] = str(item.get("type", "string"))
            return normalized
        return {}
