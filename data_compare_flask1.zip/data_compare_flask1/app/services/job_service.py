from __future__ import annotations

import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Any, Callable


class JobService:
    """Simple in-memory async job runner for long-running compare/analyze tasks."""

    def __init__(self, max_workers: int = 2) -> None:
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self._jobs: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()

    def submit(self, fn: Callable[[], Any], label: str) -> str:
        job_id = uuid.uuid4().hex
        with self._lock:
            self._jobs[job_id] = {
                "id": job_id,
                "label": label,
                "status": "running",
                "result": None,
                "error": None,
                "created_at": datetime.utcnow().isoformat(),
                "completed_at": None,
            }

        future = self.executor.submit(fn)
        future.add_done_callback(lambda fut: self._handle_done(job_id, fut))
        return job_id

    def get(self, job_id: str) -> dict[str, Any] | None:
        with self._lock:
            return self._jobs.get(job_id)

    def _handle_done(self, job_id: str, future) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job:
                return
            try:
                job["result"] = future.result()
                job["status"] = "completed"
            except Exception as exc:  # noqa: BLE001
                job["error"] = str(exc)
                job["status"] = "failed"
            job["completed_at"] = datetime.utcnow().isoformat()

