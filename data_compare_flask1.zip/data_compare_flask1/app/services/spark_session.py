from __future__ import annotations

import os
import sys
import threading
import time
from pathlib import Path

import pyspark
from pyspark.sql import SparkSession


class SparkSessionManager:
    """Creates Spark session lazily and reuses it until TTL expires."""

    def __init__(
        self,
        app_name: str,
        ttl_seconds: int,
        snowflake_spark_package: str = "",
        snowflake_jdbc_package: str = "",
        spark_extra_jars: str = "",
    ) -> None:
        self.app_name = app_name
        self.ttl_seconds = ttl_seconds
        self.snowflake_spark_package = snowflake_spark_package
        self.snowflake_jdbc_package = snowflake_jdbc_package
        self.spark_extra_jars = spark_extra_jars
        self._session: SparkSession | None = None
        self._last_used: float = 0.0
        self._lock = threading.Lock()

    def get_session(self) -> SparkSession:
        with self._lock:
            now = time.time()
            if self._session is None or (now - self._last_used) > self.ttl_seconds:
                if self._session is not None:
                    self._session.stop()
                # Keep worker python consistent with current runtime.
                # Force bundled PySpark home to avoid SPARK_HOME version mismatch
                # (for example global Spark 4.x with local PySpark 3.5.x).
                pyspark_home = str(Path(pyspark.__file__).resolve().parent)
                os.environ["SPARK_HOME"] = pyspark_home
                os.environ.setdefault("PYSPARK_PYTHON", sys.executable)
                os.environ.setdefault("PYSPARK_DRIVER_PYTHON", sys.executable)
                warehouse_path = str((Path.cwd() / ".spark-warehouse").resolve())
                ivy_cache_path = Path.cwd() / ".ivy2"
                ivy_cache_path.mkdir(parents=True, exist_ok=True)
                builder = (
                    SparkSession.builder.appName(self.app_name)
                    .master("local[*]")
                    .config("spark.sql.session.timeZone", "UTC")
                    .config("spark.sql.warehouse.dir", warehouse_path)
                    .config("spark.jars.ivy", str(ivy_cache_path.resolve()))
                    .config("spark.driver.host", "127.0.0.1")
                    .config("spark.driver.bindAddress", "127.0.0.1")
                    .config("spark.ui.enabled", "false")
                )
                packages = [self.snowflake_spark_package, self.snowflake_jdbc_package]
                packages = [pkg.strip() for pkg in packages if pkg and pkg.strip()]
                if packages:
                    builder = builder.config("spark.jars.packages", ",".join(packages))
                if self.spark_extra_jars:
                    builder = builder.config("spark.jars", self.spark_extra_jars)
                self._session = builder.getOrCreate()
            self._last_used = now
            return self._session
