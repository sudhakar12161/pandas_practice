from __future__ import annotations

import threading
import time
from pathlib import Path

from pyspark.sql import SparkSession


class SparkSessionManager:
    """Creates Spark session lazily and reuses it until TTL expires."""

    def __init__(self, app_name: str, ttl_seconds: int) -> None:
        self.app_name = app_name
        self.ttl_seconds = ttl_seconds
        self._session: SparkSession | None = None
        self._last_used: float = 0.0
        self._lock = threading.Lock()

    def get_session(self) -> SparkSession:
        with self._lock:
            now = time.time()
            if self._session is None or (now - self._last_used) > self.ttl_seconds:
                if self._session is not None:
                    self._session.stop()
                warehouse_path = str((Path.cwd() / ".spark-warehouse").resolve())
                self._session = (
                    SparkSession.builder.appName(self.app_name)
                    .config("spark.sql.session.timeZone", "UTC")
                    .config("spark.sql.warehouse.dir", warehouse_path)
                    .getOrCreate()
                )
            self._last_used = now
            return self._session

