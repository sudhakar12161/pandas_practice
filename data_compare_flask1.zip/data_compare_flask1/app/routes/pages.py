from __future__ import annotations

from flask import Blueprint, render_template

pages_bp = Blueprint("pages", __name__)


@pages_bp.get("/")
def index():
    return render_template("data_compare.html", active_page="data_compare")


@pages_bp.get("/view-schema")
def view_schema():
    return render_template("view_schema.html", active_page="view_schema")


@pages_bp.get("/view-connections")
def view_connections():
    return render_template("view_connections.html", active_page="view_connections")

