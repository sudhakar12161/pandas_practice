from __future__ import annotations

import json
import logging
import time
import uuid
from pathlib import Path
from typing import Any

import pandas as pd
from flask import Blueprint, current_app, jsonify, request, send_file
from werkzeug.exceptions import HTTPException
from werkzeug.utils import secure_filename

from app.services.compare_service import CompareService
from app.services.connection_service import ConnectionService
from app.services.job_service import JobService
from app.services.schema_service import SchemaService
from app.utils.constants import CONNECTION_TYPES
from app.utils.validators import validate_side_for_compare

api_bp = Blueprint("api", __name__, url_prefix="/api")
logger = logging.getLogger("data_compare.api")


@api_bp.errorhandler(HTTPException)
def handle_http_exception(error: HTTPException):
    """Always return JSON for API errors."""
    return jsonify({"ok": False, "error": error.description}), error.code


@api_bp.errorhandler(Exception)
def handle_unexpected_exception(error: Exception):
    """Prevent HTML traceback pages from API routes."""
    current_app.logger.exception("Unhandled API error: %s", error)
    return jsonify({"ok": False, "error": str(error) or "Unexpected server error"}), 500


def _connection_service() -> ConnectionService:
    return current_app.config["services"]["connections"]


def _schema_service() -> SchemaService:
    return current_app.config["services"]["schemas"]


def _compare_service() -> CompareService:
    return current_app.config["services"]["compare_pyspark"]


def _compare_service_for_framework(framework: str | None) -> CompareService:
    fw = (framework or "pyspark").strip().lower()
    if fw == "polars":
        return current_app.config["services"]["compare_polars"]
    return current_app.config["services"]["compare_pyspark"]


def _job_service() -> JobService:
    return current_app.config["services"]["jobs"]


def _build_side_payload(raw: dict[str, Any], uploaded_path: str | None = None) -> dict[str, Any]:
    conn_id = raw.get("connection_id")
    connection = _connection_service().get_connection(int(conn_id)) if conn_id else None
    return {
        "connection": connection,
        "table_name": raw.get("table_name"),
        "where_condition": raw.get("where_condition"),
        "file_path": raw.get("file_path"),
        "uploaded_path": uploaded_path or raw.get("uploaded_path"),
        "uploaded_name": raw.get("uploaded_name"),
        "schema_name": raw.get("schema_name", "NONE"),
    }


def _resolve_saved_schema(schema_name: str | None) -> dict[str, Any] | None:
    if not schema_name or schema_name in {"NONE", "INFER_SCHEMA"}:
        return None
    return _schema_service().get_schema(schema_name)


def _validate_analyze_request(
    source: dict[str, Any],
    target: dict[str, Any],
    pk_columns: list[str],
) -> list[str]:
    errors = validate_side_for_compare(source, "Source") + validate_side_for_compare(target, "Target")
    if not pk_columns:
        errors.append("Primary key columns are required for duplicate metrics")
    return errors


def _validate_compare_data_request(
    source: dict[str, Any],
    target: dict[str, Any],
    source_pk_columns: list[str],
    target_pk_columns: list[str],
    column_mapping: dict[str, str],
) -> list[str]:
    errors = validate_side_for_compare(source, "Source") + validate_side_for_compare(target, "Target")
    if source.get("schema_name") in (None, "", "NONE") or target.get("schema_name") in (None, "", "NONE"):
        errors.append("Schema Name is required for both Source and Target before Compare Data")
    if not source_pk_columns or not target_pk_columns:
        errors.append("Primary key columns are required on both Source and Target")
    if source_pk_columns and target_pk_columns and len(source_pk_columns) != len(target_pk_columns):
        errors.append("Source and Target primary key column counts must match")
    if not column_mapping:
        errors.append("column mapping is required")
    return errors


def _resolve_compare_schemas_or_error(source: dict[str, Any], target: dict[str, Any], framework: str | None):
    compare_service = _compare_service_for_framework(framework)
    source_schema_row = _resolve_saved_schema(source.get("schema_name"))
    target_schema_row = _resolve_saved_schema(target.get("schema_name"))
    if source.get("schema_name") not in {"INFER_SCHEMA"} and source_schema_row is None:
        return None, jsonify({"ok": False, "error": "Source selected schema not found"}), 404
    if target.get("schema_name") not in {"INFER_SCHEMA"} and target_schema_row is None:
        return None, jsonify({"ok": False, "error": "Target selected schema not found"}), 404

    source["schema_def"] = compare_service.resolve_schema(source, source_schema_row)
    target["schema_def"] = compare_service.resolve_schema(target, target_schema_row)
    return compare_service, None, None


@api_bp.get("/connection-types")
def connection_types():
    return jsonify({"types": CONNECTION_TYPES})


@api_bp.get("/connections")
def list_connections():
    logger.info("List connections requested")
    return jsonify({"items": _connection_service().list_connections()})


@api_bp.post("/connections")
def create_connection():
    payload = request.get_json(force=True)
    logger.info("Create connection requested type=%s name=%s", payload.get("type"), payload.get("name"))
    ok, errors = _connection_service().create_connection(payload)
    if not ok:
        return jsonify({"ok": False, "errors": errors}), 400
    return jsonify({"ok": True})


@api_bp.put("/connections/<int:conn_id>")
def update_connection(conn_id: int):
    payload = request.get_json(force=True)
    logger.info("Update connection requested id=%s type=%s", conn_id, payload.get("type"))
    ok, errors = _connection_service().update_connection(conn_id, payload)
    if not ok:
        status = 404 if "connection not found" in errors else 400
        return jsonify({"ok": False, "errors": errors}), status
    return jsonify({"ok": True})


@api_bp.delete("/connections/<int:conn_id>")
def delete_connection(conn_id: int):
    logger.info("Delete connection requested id=%s", conn_id)
    _connection_service().delete_connection(conn_id)
    return jsonify({"ok": True})


@api_bp.get("/schemas")
def list_schemas():
    logger.info("List schemas requested")
    search = request.args.get("search", "").strip().lower()
    items = _schema_service().list_schemas()
    if search:
        items = [item for item in items if search in item["schema_name"].lower()]
    return jsonify({"items": items})


@api_bp.post("/schemas")
def create_schema():
    payload = request.get_json(force=True)
    logger.info("Save schema requested schema_name=%s", payload.get("schema_name"))
    ok, error = _schema_service().create_schema(payload.get("schema_name"), payload.get("schema_def"))
    if not ok:
        return jsonify({"ok": False, "error": error}), 400
    return jsonify({"ok": True})


@api_bp.delete("/schemas/<int:schema_id>")
def delete_schema(schema_id: int):
    logger.info("Delete schema requested id=%s", schema_id)
    _schema_service().delete_schema(schema_id)
    return jsonify({"ok": True})


@api_bp.get("/schemas/download")
def download_schemas():
    items = _schema_service().list_schemas()
    rows = [{"schema_name": i["schema_name"], "schema_def": json.dumps(i["schema_def"])} for i in items]
    export_path = Path(current_app.config["EXPORT_DIR"]) / "schemas_export.xlsx"
    pd.DataFrame(rows).to_excel(export_path, index=False)
    return send_file(export_path, as_attachment=True, download_name="schemas_export.xlsx")


@api_bp.post("/upload")
def upload_local_file():
    start = time.perf_counter()
    file = request.files.get("file")
    if file is None:
        return jsonify({"ok": False, "error": "file is required"}), 400

    upload_dir = Path(current_app.config["UPLOAD_DIR"])
    upload_dir.mkdir(parents=True, exist_ok=True)
    file_name = f"{uuid.uuid4().hex}_{secure_filename(file.filename)}"
    file_path = upload_dir / file_name
    file.save(file_path)
    stem = Path(file.filename).stem
    elapsed = (time.perf_counter() - start) * 1000
    logger.info("Upload completed file=%s size=%sB elapsed_ms=%.1f", file.filename, file_path.stat().st_size, elapsed)
    return jsonify({"ok": True, "path": str(file_path), "uploaded_name": stem})


@api_bp.post("/schema-preview")
def schema_preview():
    try:
        start = time.perf_counter()
        payload = request.get_json(force=True)
        framework = payload.get("framework")
        side = _build_side_payload(payload)
        logger.info(
            "Schema preview requested framework=%s conn_id=%s conn_type=%s table=%s schema_mode=%s",
            framework or "pyspark",
            payload.get("connection_id"),
            (side.get("connection") or {}).get("type"),
            payload.get("table_name"),
            payload.get("schema_name"),
        )
        if not side["connection"]:
            return jsonify({"ok": False, "error": "connection is required"}), 400

        require_source = side.get("schema_name") == "INFER_SCHEMA"
        errors = validate_side_for_compare(side, "Selection", require_data_source=require_source)
        if errors:
            return jsonify({"ok": False, "errors": errors}), 400

        saved_schema = _resolve_saved_schema(side.get("schema_name"))
        if side.get("schema_name") not in {"NONE", "INFER_SCHEMA"} and not saved_schema:
            return jsonify({"ok": False, "error": "selected schema not found"}), 404

        side["schema_def"] = saved_schema["schema_def"] if saved_schema else None
        schema, schema_columns = _compare_service_for_framework(framework).resolve_schema_with_order(side, saved_schema)
        elapsed = (time.perf_counter() - start) * 1000
        logger.info("Schema preview completed framework=%s columns=%s elapsed_ms=%.1f", framework or "pyspark", len(schema), elapsed)
        return jsonify({"ok": True, "schema": schema, "schema_columns": schema_columns})
    except Exception as exc:
        current_app.logger.exception("Schema preview failed")
        return jsonify({"ok": False, "error": str(exc) or "Schema preview failed"}), 500


@api_bp.post("/compare/schema")
def compare_schema():
    start = time.perf_counter()
    payload = request.get_json(force=True)
    framework = payload.get("framework")
    logger.info("Compare schema requested framework=%s", framework or "pyspark")
    source = _build_side_payload(payload.get("source", {}))
    target = _build_side_payload(payload.get("target", {}))

    source_requires_data = source.get("schema_name") in {"NONE", "INFER_SCHEMA"}
    target_requires_data = target.get("schema_name") in {"NONE", "INFER_SCHEMA"}
    errors = validate_side_for_compare(
        source,
        "Source",
        require_data_source=source_requires_data,
    ) + validate_side_for_compare(target, "Target", require_data_source=target_requires_data)
    if errors:
        return jsonify({"ok": False, "errors": errors}), 400

    source_schema_row = _resolve_saved_schema(source.get("schema_name"))
    target_schema_row = _resolve_saved_schema(target.get("schema_name"))
    source["schema_def"] = source_schema_row["schema_def"] if source_schema_row else None
    target["schema_def"] = target_schema_row["schema_def"] if target_schema_row else None

    compare_service = _compare_service_for_framework(framework)
    source_schema, source_schema_columns = compare_service.resolve_schema_with_order(source, source_schema_row)
    target_schema, target_schema_columns = compare_service.resolve_schema_with_order(target, target_schema_row)
    rows = compare_service.compare_schema(source_schema, target_schema)
    elapsed = (time.perf_counter() - start) * 1000
    logger.info("Compare schema completed framework=%s rows=%s elapsed_ms=%.1f", framework or "pyspark", len(rows), elapsed)
    return jsonify(
        {
            "ok": True,
            "rows": rows,
            "source_schema": source_schema,
            "target_schema": target_schema,
            "source_schema_columns": source_schema_columns,
            "target_schema_columns": target_schema_columns,
        }
    )


@api_bp.post("/compare/analyze")
def analyze_data():
    start = time.perf_counter()
    payload = request.get_json(force=True)
    framework = payload.get("framework")
    logger.info("Analyze data requested framework=%s", framework or "pyspark")
    source = _build_side_payload(payload.get("source", {}))
    target = _build_side_payload(payload.get("target", {}))
    exclude_columns = payload.get("exclude_columns", [])
    pk_columns = payload.get("pk_columns", [])

    errors = _validate_analyze_request(source, target, pk_columns)
    if errors:
        return jsonify({"ok": False, "errors": errors}), 400

    compare_service = _compare_service_for_framework(framework)
    source_metrics = compare_service.analyze(source, exclude_columns, pk_columns)
    target_metrics = compare_service.analyze(target, exclude_columns, pk_columns)
    excel_path = compare_service.export_analysis_excel(source_metrics, target_metrics)
    elapsed = (time.perf_counter() - start) * 1000
    logger.info("Analyze data completed framework=%s elapsed_ms=%.1f excel=%s", framework or "pyspark", elapsed, excel_path)
    return jsonify({"ok": True, "source_metrics": source_metrics, "target_metrics": target_metrics, "excel_path": excel_path})


@api_bp.post("/jobs/analyze")
def analyze_data_job():
    payload = request.get_json(force=True)
    framework = payload.get("framework")
    logger.info("Analyze async job submitted framework=%s", framework or "pyspark")
    source = _build_side_payload(payload.get("source", {}))
    target = _build_side_payload(payload.get("target", {}))
    exclude_columns = payload.get("exclude_columns", [])
    pk_columns = payload.get("pk_columns", [])

    errors = _validate_analyze_request(source, target, pk_columns)
    if errors:
        return jsonify({"ok": False, "errors": errors}), 400

    compare_service = _compare_service_for_framework(framework)

    def run_job():
        source_metrics = compare_service.analyze(source, exclude_columns, pk_columns)
        target_metrics = compare_service.analyze(target, exclude_columns, pk_columns)
        excel_path = compare_service.export_analysis_excel(source_metrics, target_metrics)
        return {"source_metrics": source_metrics, "target_metrics": target_metrics, "excel_path": excel_path}

    job_id = _job_service().submit(run_job, "analyze")
    return jsonify({"ok": True, "job_id": job_id})


@api_bp.post("/compare/data")
def compare_data():
    start = time.perf_counter()
    payload = request.get_json(force=True)
    framework = payload.get("framework")
    logger.info("Compare data requested framework=%s", framework or "pyspark")
    source = _build_side_payload(payload.get("source", {}))
    target = _build_side_payload(payload.get("target", {}))
    source_pk_columns = payload.get("source_pk_columns", [])
    target_pk_columns = payload.get("target_pk_columns", [])
    column_mapping = payload.get("column_mapping", {})

    errors = _validate_compare_data_request(
        source,
        target,
        source_pk_columns,
        target_pk_columns,
        column_mapping,
    )
    if errors:
        return jsonify({"ok": False, "errors": errors}), 400

    compare_service, error_response, error_code = _resolve_compare_schemas_or_error(source, target, framework)
    if error_response is not None:
        return error_response, error_code

    result = compare_service.compare_data(
        source,
        target,
        source_pk_columns,
        target_pk_columns,
        column_mapping,
    )
    elapsed = (time.perf_counter() - start) * 1000
    logger.info(
        "Compare data completed framework=%s elapsed_ms=%.1f source_total=%s target_total=%s",
        framework or "pyspark",
        elapsed,
        result.get("source", {}).get("total_rows"),
        result.get("target", {}).get("total_rows"),
    )
    return jsonify({"ok": True, "report": result})


@api_bp.post("/jobs/compare-data")
def compare_data_job():
    payload = request.get_json(force=True)
    framework = payload.get("framework")
    logger.info("Compare data async job submitted framework=%s", framework or "pyspark")
    source = _build_side_payload(payload.get("source", {}))
    target = _build_side_payload(payload.get("target", {}))
    source_pk_columns = payload.get("source_pk_columns", [])
    target_pk_columns = payload.get("target_pk_columns", [])
    column_mapping = payload.get("column_mapping", {})

    errors = _validate_compare_data_request(
        source,
        target,
        source_pk_columns,
        target_pk_columns,
        column_mapping,
    )
    if errors:
        return jsonify({"ok": False, "errors": errors}), 400

    compare_service, error_response, error_code = _resolve_compare_schemas_or_error(source, target, framework)
    if error_response is not None:
        return error_response, error_code

    def run_job():
        report = compare_service.compare_data(
            source,
            target,
            source_pk_columns,
            target_pk_columns,
            column_mapping,
        )
        return {"report": report}

    job_id = _job_service().submit(run_job, "compare-data")
    return jsonify({"ok": True, "job_id": job_id})


@api_bp.post("/data-preview")
def data_preview():
    payload = request.get_json(force=True)
    framework = payload.get("framework")
    side = _build_side_payload(payload.get("side", {}))
    if not side.get("connection"):
        return jsonify({"ok": False, "error": "connection is required"}), 400
    if side.get("schema_name") in (None, "", "NONE"):
        return jsonify({"ok": False, "error": "Schema Name is required for Data Preview and cannot be None"}), 400

    errors = validate_side_for_compare(side, "Selection", require_data_source=True)
    if errors:
        return jsonify({"ok": False, "errors": errors}), 400

    compare_service = _compare_service_for_framework(framework)
    saved_schema = _resolve_saved_schema(side.get("schema_name"))
    if side.get("schema_name") not in {"NONE", None, ""} and side.get("schema_name") != "INFER_SCHEMA" and not saved_schema:
        return jsonify({"ok": False, "error": "selected schema not found"}), 404
    side["schema_def"] = compare_service.resolve_schema(side, saved_schema) if side.get("schema_name") != "NONE" else None

    limit = int(payload.get("limit", 100))
    offset = int(payload.get("offset", 0))
    result = compare_service.preview_data(side, limit=limit, offset=offset)
    return jsonify({"ok": True, "preview": result})


@api_bp.get("/jobs/<string:job_id>")
def get_job_status(job_id: str):
    job = _job_service().get(job_id)
    logger.info("Job status requested job_id=%s status=%s", job_id, (job or {}).get("status"))
    if not job:
        return jsonify({"ok": False, "error": "job not found"}), 404
    return jsonify({"ok": True, "job": job})


@api_bp.get("/exports/<path:file_name>")
def download_export(file_name: str):
    export_dir = Path(current_app.config["EXPORT_DIR"])
    file_path = export_dir / file_name
    if not file_path.exists():
        return jsonify({"ok": False, "error": "file not found"}), 404
    return send_file(file_path, as_attachment=True, download_name=file_path.name)


@api_bp.get("/health")
def health():
    return jsonify({"ok": True})
