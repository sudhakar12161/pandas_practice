#!/bin/sh
set -eu

echo "Waiting for Postgres TCP readiness at ${PGHOST}:${PGPORT}..."
for attempt in $(seq 1 60); do
  if pg_isready -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$POSTGRES_DB" >/dev/null 2>&1; then
    break
  fi
  if [ "$attempt" -eq 60 ]; then
    echo "Postgres did not become ready in time." >&2
    exit 1
  fi
  sleep 2
done

psql -v ON_ERROR_STOP=1 --dbname "$POSTGRES_DB" <<SQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '${POLARIS_DB_USER}') THEN
    CREATE USER ${POLARIS_DB_USER} WITH PASSWORD '${POLARIS_DB_PASSWORD}';
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '${SUPERSET_DB_USER}') THEN
    CREATE USER ${SUPERSET_DB_USER} WITH PASSWORD '${SUPERSET_DB_PASSWORD}';
  END IF;
END
\$\$;

SELECT 'CREATE DATABASE ${POLARIS_DB} OWNER ${POLARIS_DB_USER}'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '${POLARIS_DB}')\gexec

SELECT 'CREATE DATABASE ${SUPERSET_DB} OWNER ${SUPERSET_DB_USER}'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '${SUPERSET_DB}')\gexec
SQL

echo "Runtime Postgres init complete."
