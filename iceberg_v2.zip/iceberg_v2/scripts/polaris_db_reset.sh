#!/bin/sh
set -eu

echo "Resetting local Polaris JDBC metastore database '$POLARIS_DB'."
echo "This removes Polaris catalogs, principals, roles, grants, and table registrations."

for attempt in $(seq 1 60); do
  if pg_isready -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$POSTGRES_DB" >/dev/null 2>&1; then
    break
  fi
  if [ "$attempt" -eq 60 ]; then
    echo "Postgres did not become ready in time." >&2
    exit 1
  fi
  sleep 2
done

psql -v ON_ERROR_STOP=1 --dbname "$POSTGRES_DB" <<SQL
SELECT pg_terminate_backend(pid)
FROM pg_stat_activity
WHERE datname = '${POLARIS_DB}' AND pid <> pg_backend_pid();

DROP DATABASE IF EXISTS ${POLARIS_DB};
CREATE DATABASE ${POLARIS_DB} OWNER ${POLARIS_DB_USER};
SQL

echo "Polaris database reset complete."
