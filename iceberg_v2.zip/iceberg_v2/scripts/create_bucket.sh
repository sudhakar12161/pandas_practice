#!/bin/sh
set -eu

until aws --endpoint-url "$AWS_ENDPOINT_URL" s3 ls >/dev/null 2>&1; do
  echo "Waiting for RustFS S3 API..."
  sleep 3
done

aws --endpoint-url "$AWS_ENDPOINT_URL" s3 mb "s3://$RUSTFS_BUCKET" 2>/dev/null || true
aws --endpoint-url "$AWS_ENDPOINT_URL" s3 ls

