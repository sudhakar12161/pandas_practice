#!/bin/sh
set -eu

superset db upgrade

superset fab create-admin \
  --username "$SUPERSET_ADMIN_USERNAME" \
  --firstname Lakehouse \
  --lastname Admin \
  --email "$SUPERSET_ADMIN_EMAIL" \
  --password "$SUPERSET_ADMIN_PASSWORD" || true

superset init

superset fab create-user \
  --username developer1 \
  --firstname Developer \
  --lastname One \
  --email developer1@example.local \
  --role Alpha \
  --password "$DEVELOPER1_PASSWORD" || true

superset fab create-user \
  --username developer2 \
  --firstname Developer \
  --lastname Two \
  --email developer2@example.local \
  --role Alpha \
  --password "$DEVELOPER2_PASSWORD" || true

superset fab create-user \
  --username analyst \
  --firstname Lakehouse \
  --lastname Analyst \
  --email analyst@example.local \
  --role Gamma \
  --password "$ANALYST_PASSWORD" || true

exec /usr/bin/run-server.sh

