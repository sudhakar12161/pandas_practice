import os
from pathlib import Path

import polars as pl
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count, current_timestamp, sum as sum_


ROOT = Path(__file__).resolve().parents[1]


def load_env_file(path: Path) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())


load_env_file(ROOT / ".env")
load_env_file(ROOT / "volumes" / "polaris" / "local_polaris_credentials.env")

ICEBERG_VERSION = os.getenv("ICEBERG_VERSION", "1.10.1")
REGION = os.getenv("RUSTFS_REGION", "us-east-1")
ACCESS_KEY = os.environ["RUSTFS_ACCESS_KEY"]
SECRET_KEY = os.environ["RUSTFS_SECRET_KEY"]
CATALOG_NAME = os.getenv("POLARIS_CATALOG_NAME", "lakehouse")
CLIENT_ID = os.getenv("POLARIS_DEVELOPER1_CLIENT_ID", os.getenv("POLARIS_ROOT_CLIENT_ID", "root"))
CLIENT_SECRET = os.getenv("POLARIS_DEVELOPER1_CLIENT_SECRET", os.environ["POLARIS_ROOT_CLIENT_SECRET"])


def spark_session() -> SparkSession:
    packages = ",".join(
        [
            f"org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:{ICEBERG_VERSION}",
            f"org.apache.iceberg:iceberg-aws-bundle:{ICEBERG_VERSION}",
        ]
    )

    return (
        SparkSession.builder.appName("local-csv-to-iceberg")
        .master("local[*]")
        .config("spark.jars.packages", packages)
        .config(
            "spark.sql.extensions",
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
        )
        .config("spark.sql.defaultCatalog", "lakehouse")
        .config("spark.sql.catalog.lakehouse", "org.apache.iceberg.spark.SparkCatalog")
        .config("spark.sql.catalog.lakehouse.type", "rest")
        .config("spark.sql.catalog.lakehouse.uri", "http://localhost:8181/api/catalog")
        .config("spark.sql.catalog.lakehouse.warehouse", CATALOG_NAME)
        .config("spark.sql.catalog.lakehouse.credential", f"{CLIENT_ID}:{CLIENT_SECRET}")
        .config("spark.sql.catalog.lakehouse.scope", "PRINCIPAL_ROLE:ALL")
        .config("spark.sql.catalog.lakehouse.token-refresh-enabled", "true")
        .config("spark.sql.catalog.lakehouse.s3.endpoint", "http://localhost:9000")
        .config("spark.sql.catalog.lakehouse.s3.region", REGION)
        .config("spark.sql.catalog.lakehouse.s3.path-style-access", "true")
        .config("spark.sql.catalog.lakehouse.s3.access-key-id", ACCESS_KEY)
        .config("spark.sql.catalog.lakehouse.s3.secret-access-key", SECRET_KEY)
        .config("spark.sql.catalog.lakehouse.client.region", REGION)
        .config("spark.sql.shuffle.partitions", "4")
        .getOrCreate()
    )


def main() -> None:
    csv_path = ROOT / "data" / "customers.csv"
    preview = pl.read_csv(csv_path)
    print(f"Polars validation: {csv_path} has {preview.height} rows and {len(preview.columns)} columns")

    spark = spark_session()
    spark.sql("CREATE NAMESPACE IF NOT EXISTS raw")
    spark.sql("CREATE NAMESPACE IF NOT EXISTS curated")
    spark.sql("CREATE NAMESPACE IF NOT EXISTS dev_developer1")
    spark.sql("CREATE NAMESPACE IF NOT EXISTS dev_developer2")

    df = (
        spark.read.option("header", True)
        .option("inferSchema", True)
        .csv(str(csv_path))
        .withColumn("ingested_at", current_timestamp())
    )

    (
        df.writeTo("raw.customers")
        .using("iceberg")
        .tableProperty("format-version", "2")
        .tableProperty("write.format.default", "parquet")
        .tableProperty("write.parquet.compression-codec", "zstd")
        .createOrReplace()
    )

    by_state = (
        df.groupBy("state")
        .agg(count("*").alias("customer_count"), sum_(col("monthly_amount")).alias("monthly_revenue"))
        .orderBy("state")
    )

    (
        by_state.writeTo("curated.customer_revenue_by_state")
        .using("iceberg")
        .tableProperty("format-version", "2")
        .createOrReplace()
    )

    print("Created Iceberg tables:")
    spark.sql("SHOW TABLES IN raw").show(truncate=False)
    spark.sql("SHOW TABLES IN curated").show(truncate=False)
    spark.stop()


if __name__ == "__main__":
    main()
