import time

import requests
import trino

TRINO_HOST = "localhost"
TRINO_PORT = 8090


def wait_for_trino() -> None:
    for _ in range(60):
        try:
            response = requests.get(f"http://{TRINO_HOST}:{TRINO_PORT}/v1/info", timeout=3)
            if response.ok:
                return
        except requests.RequestException:
            pass
        time.sleep(2)
    raise RuntimeError("Trino did not become ready in time")


def query(user: str, sql: str):
    conn = trino.dbapi.connect(host=TRINO_HOST, port=TRINO_PORT, user=user, catalog="iceberg")
    cur = conn.cursor()
    cur.execute(sql)
    return cur.fetchall()


def main() -> None:
    wait_for_trino()

    print("Admin can inspect catalogs:")
    print(query("admin", "SHOW CATALOGS"))

    print("Analyst can read curated table:")
    print(query("analyst", "SELECT * FROM curated.customer_revenue_by_state ORDER BY state"))

    print("Developer can read raw table:")
    print(query("developer1", "SELECT count(*) FROM raw.customers"))

    try:
        query(
            "analyst",
            "INSERT INTO curated.customer_revenue_by_state VALUES ('ZZ', 0, 0.00)",
        )
    except Exception as exc:
        print("Expected: analyst write was blocked by Trino file access control.")
        print(str(exc).splitlines()[0])
    else:
        raise RuntimeError("Analyst unexpectedly wrote to an Iceberg table")

    print("Validation complete.")


if __name__ == "__main__":
    main()
