# Local Production-Shaped Iceberg Lakehouse With Apache Polaris

This project runs a small local lakehouse with production-style boundaries:

- Apache Polaris `1.4.0` is the Iceberg REST catalog.
- Polaris metadata is persisted in Postgres with relational JDBC persistence.
- RustFS is the local S3-compatible object store.
- `amazon/aws-cli` creates the RustFS bucket.
- Trino queries Iceberg tables through Polaris.
- Superset connects to Trino for BI.
- A small Flask admin app manages common Polaris principal/role/grant tasks.
- PySpark `3.5.6` and Polars `1.4.0` run from your local machine, not from Docker.

## Architecture

```text
local CSV
  -> local Polars validation
  -> local PySpark 3.5.6
  -> Apache Polaris 1.4.0 Iceberg REST catalog
  -> Postgres relational JDBC persistence
  -> RustFS S3-compatible warehouse
  -> Trino SQL
  -> Superset dashboards

Polaris admin browser UI
  -> Polaris management API
  -> principals, roles, grants
```

## Accounts

Polaris uses service principals. The setup creates:

| Principal | Polaris privilege shape | Usage |
| --- | --- | --- |
| `admin` | Full catalog content management | Platform/catalog admin workflows. |
| `developer1` | Full catalog content management | Local PySpark writer by default. |
| `developer2` | Full catalog content management | Second developer identity. |
| `analyst` | Read-oriented catalog/table privileges | Read-only BI/analytics workflows. |

Trino also has file access rules in `docker/trino/etc/rules.json` for the usernames `admin`, `developer1`, `developer2`, and `analyst`.

## Prerequisites

- Docker Desktop with Compose.
- Python 3.8+ available locally.
- Java 17 available locally for PySpark.
- Ports available: `5432`, `8088`, `8090`, `8181`, `8182`, `9000`, `9001`.

## Configure Secrets

The project includes a local `.env` so it can run immediately. For your own copy:

```powershell
Copy-Item .env.example .env
```

Then edit `.env` and change every password. Credentials are not stored in Dockerfiles.

Durable service state is stored under:

```text
./volumes/
```

You can change that with `PROJECT_DATA_ROOT` in `.env`.

## Project Files And What They Do

This section maps each file to the step that uses it.

| File | Used by | Purpose |
| --- | --- | --- |
| `.env` | Docker Compose and local PySpark jobs | Local secrets and runtime settings. Keep private. |
| `.env.example` | You | Template for recreating `.env` safely. |
| `docker-compose.yml` | `docker compose up` | Defines Postgres, RustFS, Polaris, Trino, Superset, and one-time setup services. |
| `requirements-local.txt` | Local Python virtual environment | Installs PySpark `3.5.6`, Polars `1.4.0`, Trino client, and Requests on your machine. |
| `data/customers.csv` | `jobs/write_csv_to_iceberg.py` | Example source CSV loaded into Iceberg. |
| `jobs/write_csv_to_iceberg.py` | You run locally with Python | Validates CSV with Polars, starts local PySpark, connects to Polaris, and writes Iceberg tables. |
| `jobs/validate_lakehouse.py` | You run locally with Python | Checks Trino visibility and confirms analyst read-only behavior. |
| `docker/postgres/initdb/01-create-databases.sh` | Postgres container on first-ever DB initialization | Creates the Polaris and Superset databases when the Postgres volume is brand new. |
| `scripts/postgres_init_runtime.sh` | `postgres-init` service | Idempotently ensures Polaris and Superset DB/users exist even when the Postgres volume already exists. |
| `scripts/create_bucket.sh` | `create-bucket` service | Uses AWS CLI to wait for RustFS and create the `warehouse` bucket. |
| `scripts/polaris_setup.sh` | `polaris-setup` service | Creates the Polaris catalog, principals, roles, grants, and generated service credentials. |
| `scripts/polaris_db_reset.sh` | `polaris-db-reset` profile | Resets only the Polaris database if the local Polaris metastore is partially bootstrapped. |
| `scripts/superset_bootstrap.sh` | Superset container startup | Runs Superset DB migrations and creates admin/developer/analyst users. |
| `apps/polaris_admin/app.py` | `polaris-admin` service | Flask app for creating Polaris principals, roles, and grants from a browser. |
| `apps/polaris_admin/Dockerfile` | `polaris-admin` image build | Builds the Flask admin app image. |
| `apps/polaris_admin/requirements.txt` | `polaris-admin` image build | Installs Flask and Requests inside the admin app image. |
| `docker/trino/Dockerfile` | Trino image build | Copies Trino config and the runtime catalog template renderer into the image. |
| `docker/trino/render-and-run.sh` | Trino container startup | Renders `iceberg.properties` from `.env` values, then starts Trino. |
| `docker/trino/templates/iceberg.properties.template` | `render-and-run.sh` | Template for Trino's Iceberg connector pointed at Polaris and RustFS. |
| `docker/trino/etc/rules.json` | Trino startup | File-based access control for admin, developers, and analyst. |
| `docker/trino/etc/access-control.properties` | Trino startup | Enables Trino file-based access control. |
| `docker/trino/etc/config.properties` | Trino startup | Trino coordinator configuration. |
| `docker/trino/etc/node.properties` | Trino startup | Trino node identity and environment. |
| `docker/trino/etc/jvm.config` | Trino startup | JVM memory/runtime options for local Trino. |
| `docker/superset/Dockerfile` | Superset image build | Adds Trino SQLAlchemy and Postgres drivers to Superset. |
| `docker/superset/superset_config.py` | Superset startup | Points Superset at Postgres metadata DB and applies local config. |

## Startup Flow

When you run:

```powershell
docker compose --env-file .env up -d --build
```

Compose starts the platform in this order:

1. `postgres` starts and stores metadata under `volumes/postgres`.
2. `postgres-init` runs `scripts/postgres_init_runtime.sh` to ensure required DBs/users exist.
3. `rustfs-perms` fixes local RustFS volume ownership.
4. `rustfs` starts local S3-compatible storage under `volumes/rustfs`.
5. `create-bucket` runs `scripts/create_bucket.sh` with AWS CLI and creates `s3://warehouse`.
6. `polaris-bootstrap` initializes the Polaris relational JDBC metastore.
7. `polaris` starts the Iceberg REST catalog API.
8. `polaris-setup` runs `scripts/polaris_setup.sh`, creates catalog/accounts/roles, and writes generated credentials to `volumes/polaris/local_polaris_credentials.env`.
9. `trino` starts and queries Iceberg through Polaris.
10. `polaris-admin` starts a small Flask browser UI for managing Polaris principals/roles/grants.
11. `superset` starts and connects to its metadata DB in Postgres.

After that, you run local PySpark from your machine:

```powershell
python .\jobs\write_csv_to_iceberg.py
```

That script writes the actual Iceberg tables. Superset will not see datasets until this job succeeds.

## Start The Docker Services

For a completely clean local rebuild, stop containers and remove the persisted local volumes directory first:

```powershell
docker compose --env-file .env down
Remove-Item -Recurse -Force .\volumes -ErrorAction SilentlyContinue
docker compose --env-file .env up -d --build
```

For normal startup after the first clean build:

```powershell
docker compose --env-file .env up -d --build
```

If Polaris logs say `relation "polaris_schema.entities" does not exist`, the local Polaris database is partially bootstrapped. Reset only the Polaris metastore, then start again:

```powershell
docker compose --env-file .env stop polaris polaris-setup trino superset
docker compose --profile reset-polaris --env-file .env run --rm polaris-db-reset
Remove-Item -Force .\volumes\polaris\local_polaris_credentials.env -ErrorAction SilentlyContinue
docker compose --env-file .env up -d --build
```

This starts:

- Postgres
- RustFS
- AWS CLI bucket setup
- Polaris bootstrap
- Polaris server
- Polaris principal/catalog setup
- Trino
- Superset

The Polaris setup writes generated local service-principal credentials to:

```text
volumes/polaris/local_polaris_credentials.env
```

Keep that file private.

Useful URLs:

- RustFS S3 API: <http://localhost:9000>
- RustFS console: <http://localhost:9001>
- Polaris catalog API: <http://localhost:8181/api/catalog>
- Polaris health: <http://localhost:8182/q/health>
- Trino: <http://localhost:8090>
- Polaris Admin UI: <http://localhost:5000>
- Superset: <http://localhost:8088>

## Polaris Admin App

Open:

```text
http://localhost:5000
```

Use the credentials from `.env`:

```text
POLARIS_ADMIN_APP_USERNAME=admin
POLARIS_ADMIN_APP_PASSWORD=admin_app_local_pw
```

The app is intentionally small and local-only. It uses the Polaris root client credentials from `.env` to call the Polaris management API.

The app can:

- List catalogs, principals, principal roles, and catalog roles.
- Create a complete principal setup in one form.
- Create a principal only.
- Grant catalog-level privileges to a catalog role.

When the app creates a new principal, Polaris returns the principal's generated client ID and client secret once. The app appends those credentials to:

```text
volumes/polaris-admin/created_principals.env
```

Keep that file private. These are service-principal credentials for Polaris.

### Complete Principal Flow

The **Create Complete Principal** form performs the same RBAC chain as the setup script:

```text
principal
  -> principal role
  -> catalog role
  -> catalog privileges
```

For example, creating `developer3` with `CATALOG_MANAGE_CONTENT` does this:

1. Creates Polaris principal `developer3`.
2. Creates principal role `developer3_principal_role`.
3. Creates catalog role `developer3_catalog_role`.
4. Grants `developer3_principal_role` to `developer3`.
5. Grants `developer3_catalog_role` to `developer3_principal_role`.
6. Grants selected privileges to `developer3_catalog_role`.

For read-only users, choose privileges like:

```text
CATALOG_READ_PROPERTIES
NAMESPACE_LIST
NAMESPACE_READ_PROPERTIES
TABLE_LIST
TABLE_READ_PROPERTIES
TABLE_READ_DATA
TABLE_FULL_METADATA
```

For developer-style users, use:

```text
CATALOG_MANAGE_CONTENT
```

## Prepare Local PySpark

From this project directory:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements-local.txt
```

The local job uses:

- `pyspark==3.5.6`
- `polars==1.4.0`
- Iceberg Spark runtime jars resolved by Spark with `spark.jars.packages`

## Write CSV To Iceberg From Local PySpark

```powershell
python .\jobs\write_csv_to_iceberg.py
```

The job:

1. Reads `data/customers.csv` with local Polars.
2. Connects local Spark to Polaris at `http://localhost:8181/api/catalog`.
3. Uses the generated `developer1` Polaris principal by default.
4. Writes `raw.customers`.
5. Writes `curated.customer_revenue_by_state`.

## Validate End To End

```powershell
python .\jobs\validate_lakehouse.py
```

Expected checks:

- Trino is reachable from the host.
- `admin` can inspect catalogs.
- `developer1` can read `raw.customers`.
- `analyst` can read curated data.
- `analyst` cannot insert into Iceberg tables through Trino.

## Query With Trino

Admin:

```powershell
docker compose exec trino trino --server http://localhost:8080 --user admin --catalog iceberg
```

Try:

```sql
SHOW SCHEMAS;
SHOW TABLES FROM raw;
SELECT * FROM raw.customers LIMIT 10;
SELECT * FROM curated.customer_revenue_by_state ORDER BY state;
```

Analyst:

```powershell
docker compose exec trino trino --server http://localhost:8080 --user analyst --catalog iceberg
```

This should work:

```sql
SELECT * FROM curated.customer_revenue_by_state;
```

This should fail:

```sql
INSERT INTO curated.customer_revenue_by_state VALUES ('ZZ', 0, 0.00);
```

## Superset

Log in to Superset at <http://localhost:8088> with the admin credentials from `.env`.

Create a database connection:

```text
trino://analyst@trino:8080/iceberg
```

Use the analyst connection for dashboards so BI runs read-only through Trino.

## Reset

Stop containers:

```powershell
docker compose down
```

Reset all data:

```powershell
docker compose down
Remove-Item -Recurse -Force .\volumes
```

Only reset when you intentionally want to delete Postgres, RustFS, Polaris, and generated principal credentials.

## Production Gaps To Add Later

- TLS on every endpoint.
- External secret manager.
- Real identity provider for Polaris and Superset.
- Durable RSA keys or external IdP tokens for Polaris auth instead of the local symmetric token broker.
- Backups for Postgres and RustFS.
- Object-store lifecycle/retention policy.
- CI smoke test for Polaris, Spark write, Trino read, and analyst write denial.
