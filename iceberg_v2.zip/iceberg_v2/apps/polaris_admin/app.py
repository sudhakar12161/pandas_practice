import json
import os
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path

import requests
from flask import Flask, Response, flash, redirect, render_template_string, request, url_for


app = Flask(__name__)
app.secret_key = os.environ.get("POLARIS_ADMIN_APP_SECRET", "local-dev-secret-change-me")

POLARIS_BASE_URL = os.environ.get("POLARIS_BASE_URL", "http://polaris:8181")
POLARIS_REALM = os.environ.get("POLARIS_REALM", "POLARIS")
POLARIS_CATALOG_NAME = os.environ.get("POLARIS_CATALOG_NAME", "lakehouse")
POLARIS_ROOT_CLIENT_ID = os.environ["POLARIS_ROOT_CLIENT_ID"]
POLARIS_ROOT_CLIENT_SECRET = os.environ["POLARIS_ROOT_CLIENT_SECRET"]
APP_USERNAME = os.environ.get("POLARIS_ADMIN_APP_USERNAME", "admin")
APP_PASSWORD = os.environ["POLARIS_ADMIN_APP_PASSWORD"]
CREDENTIAL_LOG = Path(os.environ.get("POLARIS_ADMIN_CREDENTIAL_LOG", "/state/created_principals.env"))

CATALOG_PRIVILEGES = [
    "CATALOG_MANAGE_CONTENT",
    "CATALOG_READ_PROPERTIES",
    "CATALOG_WRITE_PROPERTIES",
    "NAMESPACE_CREATE",
    "NAMESPACE_LIST",
    "NAMESPACE_READ_PROPERTIES",
    "NAMESPACE_WRITE_PROPERTIES",
    "TABLE_CREATE",
    "TABLE_LIST",
    "TABLE_READ_PROPERTIES",
    "TABLE_WRITE_PROPERTIES",
    "TABLE_READ_DATA",
    "TABLE_WRITE_DATA",
    "TABLE_FULL_METADATA",
]


def require_basic_auth(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        auth = request.authorization
        if not auth or auth.username != APP_USERNAME or auth.password != APP_PASSWORD:
            return Response(
                "Authentication required",
                401,
                {"WWW-Authenticate": 'Basic realm="Polaris Admin"'},
            )
        return view(*args, **kwargs)

    return wrapped


class PolarisClient:
    def __init__(self):
        self._token = None

    def token(self):
        if self._token:
            return self._token
        response = requests.post(
            f"{POLARIS_BASE_URL}/api/catalog/v1/oauth/tokens",
            auth=(POLARIS_ROOT_CLIENT_ID, POLARIS_ROOT_CLIENT_SECRET),
            headers={"Polaris-Realm": POLARIS_REALM},
            data={"grant_type": "client_credentials", "scope": "PRINCIPAL_ROLE:ALL"},
            timeout=20,
        )
        response.raise_for_status()
        self._token = response.json()["access_token"]
        return self._token

    def request(self, method, path, payload=None):
        headers = {
            "Authorization": f"Bearer {self.token()}",
            "Polaris-Realm": POLARIS_REALM,
            "Accept": "application/json",
        }
        if payload is not None:
            headers["Content-Type"] = "application/json"
        response = requests.request(
            method,
            f"{POLARIS_BASE_URL}{path}",
            headers=headers,
            json=payload,
            timeout=30,
        )
        if response.status_code == 401:
            self._token = None
            headers["Authorization"] = f"Bearer {self.token()}"
            response = requests.request(
                method,
                f"{POLARIS_BASE_URL}{path}",
                headers=headers,
                json=payload,
                timeout=30,
            )
        response.raise_for_status()
        if response.text.strip():
            return response.json()
        return {}


def polaris():
    return PolarisClient()


def save_credentials(principal, credentials):
    CREDENTIAL_LOG.parent.mkdir(parents=True, exist_ok=True)
    client_id = credentials.get("clientId")
    client_secret = credentials.get("clientSecret")
    if not client_id or not client_secret:
        return
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    env_prefix = principal.upper().replace("-", "_")
    with CREDENTIAL_LOG.open("a", encoding="utf-8") as file:
        file.write(f"\n# {principal} created at {stamp} UTC\n")
        file.write(f"POLARIS_{env_prefix}_CLIENT_ID={client_id}\n")
        file.write(f"POLARIS_{env_prefix}_CLIENT_SECRET={client_secret}\n")


def safe_api(label, func):
    try:
        return func(), None
    except requests.HTTPError as exc:
        body = exc.response.text if exc.response is not None else str(exc)
        return None, f"{label} failed: HTTP {exc.response.status_code if exc.response else '?'} {body}"
    except requests.RequestException as exc:
        return None, f"{label} failed: {exc}"


def list_or_error(path):
    data, error = safe_api(f"GET {path}", lambda: polaris().request("GET", path))
    return data if error is None else {"error": error}


PAGE = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Polaris Admin</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 24px; color: #17202a; background: #f7f9fb; }
    h1, h2 { margin-bottom: 8px; }
    section { background: white; border: 1px solid #dde4ec; border-radius: 8px; padding: 16px; margin: 16px 0; }
    label { display: block; margin: 10px 0 4px; font-weight: 600; }
    input, select { width: 360px; max-width: 100%; padding: 8px; border: 1px solid #b8c4cf; border-radius: 6px; }
    button { margin-top: 12px; padding: 8px 12px; border: 0; border-radius: 6px; background: #1769aa; color: white; cursor: pointer; }
    button.secondary { background: #5f6c7b; }
    pre { white-space: pre-wrap; background: #111827; color: #e5e7eb; padding: 12px; border-radius: 6px; overflow-x: auto; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(360px, 1fr)); gap: 16px; }
    .flash { background: #fff8db; border: 1px solid #f1d36b; padding: 10px; border-radius: 6px; margin: 8px 0; }
    .checks { columns: 2; }
    .checks label { font-weight: 400; margin: 6px 0; }
  </style>
</head>
<body>
  <h1>Polaris Admin</h1>
  <p>Catalog: <strong>{{ catalog }}</strong> | Realm: <strong>{{ realm }}</strong></p>

  {% for message in messages %}
    <div class="flash">{{ message }}</div>
  {% endfor %}

  <section>
    <h2>Create Complete Principal</h2>
    <p>This creates a Polaris principal, principal role, catalog role, links them together, and grants selected catalog privileges.</p>
    <form method="post" action="{{ url_for('create_complete') }}">
      <label>Principal name</label>
      <input name="principal" placeholder="developer3" required>
      <label>Principal role</label>
      <input name="principal_role" placeholder="developer3_principal_role">
      <label>Catalog role</label>
      <input name="catalog_role" placeholder="developer3_catalog_role">
      <div class="checks">
        {% for privilege in privileges %}
          <label><input type="checkbox" name="privileges" value="{{ privilege }}" {% if privilege in default_privileges %}checked{% endif %}> {{ privilege }}</label>
        {% endfor %}
      </div>
      <button>Create Principal And Grants</button>
    </form>
  </section>

  <div class="grid">
    <section>
      <h2>Create Principal Only</h2>
      <form method="post" action="{{ url_for('create_principal') }}">
        <label>Principal name</label>
        <input name="principal" required>
        <button>Create Principal</button>
      </form>
    </section>

    <section>
      <h2>Grant Catalog Privilege</h2>
      <form method="post" action="{{ url_for('grant_privilege') }}">
        <label>Catalog role</label>
        <input name="catalog_role" required>
        <label>Privilege</label>
        <select name="privilege">
          {% for privilege in privileges %}
            <option value="{{ privilege }}">{{ privilege }}</option>
          {% endfor %}
        </select>
        <button>Grant Privilege</button>
      </form>
    </section>
  </div>

  <section>
    <h2>Current Polaris Objects</h2>
    <form method="get" action="{{ url_for('index') }}">
      <button class="secondary">Refresh</button>
    </form>
    <h3>Catalogs</h3>
    <pre>{{ catalogs }}</pre>
    <h3>Principals</h3>
    <pre>{{ principals }}</pre>
    <h3>Principal Roles</h3>
    <pre>{{ principal_roles }}</pre>
    <h3>Catalog Roles</h3>
    <pre>{{ catalog_roles }}</pre>
  </section>
</body>
</html>
"""


@app.get("/")
@require_basic_auth
def index():
    messages = list(getattr(request, "_flashes", []))
    default_privileges = ["CATALOG_MANAGE_CONTENT"]
    return render_template_string(
        PAGE,
        catalog=POLARIS_CATALOG_NAME,
        realm=POLARIS_REALM,
        privileges=CATALOG_PRIVILEGES,
        default_privileges=default_privileges,
        messages=[m[1] for m in messages],
        catalogs=json.dumps(list_or_error("/api/management/v1/catalogs"), indent=2),
        principals=json.dumps(list_or_error("/api/management/v1/principals"), indent=2),
        principal_roles=json.dumps(list_or_error("/api/management/v1/principal-roles"), indent=2),
        catalog_roles=json.dumps(
            list_or_error(f"/api/management/v1/catalogs/{POLARIS_CATALOG_NAME}/catalog-roles"),
            indent=2,
        ),
    )


@app.post("/principals")
@require_basic_auth
def create_principal():
    principal = request.form["principal"].strip()
    payload = {"principal": {"name": principal, "properties": {}}}
    data, error = safe_api(
        "Create principal",
        lambda: polaris().request("POST", "/api/management/v1/principals", payload),
    )
    if error:
        flash(error)
    else:
        credentials = data.get("credentials", {})
        save_credentials(principal, credentials)
        flash(f"Created principal {principal}. Credentials were appended to {CREDENTIAL_LOG}.")
    return redirect(url_for("index"))


@app.post("/complete-principal")
@require_basic_auth
def create_complete():
    principal = request.form["principal"].strip()
    principal_role = request.form.get("principal_role", "").strip() or f"{principal}_principal_role"
    catalog_role = request.form.get("catalog_role", "").strip() or f"{principal}_catalog_role"
    privileges = request.form.getlist("privileges") or ["CATALOG_MANAGE_CONTENT"]
    client = polaris()

    steps = [
        (
            "Create principal",
            lambda: client.request(
                "POST",
                "/api/management/v1/principals",
                {"principal": {"name": principal, "properties": {}}},
            ),
        ),
        (
            "Create principal role",
            lambda: client.request(
                "POST",
                "/api/management/v1/principal-roles",
                {"principalRole": {"name": principal_role, "properties": {}}},
            ),
        ),
        (
            "Create catalog role",
            lambda: client.request(
                "POST",
                f"/api/management/v1/catalogs/{POLARIS_CATALOG_NAME}/catalog-roles",
                {"catalogRole": {"name": catalog_role, "properties": {}}},
            ),
        ),
        (
            "Grant principal role to principal",
            lambda: client.request(
                "PUT",
                f"/api/management/v1/principals/{principal}/principal-roles",
                {"principalRole": {"name": principal_role}},
            ),
        ),
        (
            "Grant catalog role to principal role",
            lambda: client.request(
                "PUT",
                f"/api/management/v1/principal-roles/{principal_role}/catalog-roles/{POLARIS_CATALOG_NAME}",
                {"catalogRole": {"name": catalog_role}},
            ),
        ),
    ]

    created_credentials = None
    for label, action in steps:
        data, error = safe_api(label, action)
        if error:
            flash(error)
            return redirect(url_for("index"))
        if label == "Create principal":
            created_credentials = data.get("credentials", {})

    for privilege in privileges:
        _, error = safe_api(
            f"Grant {privilege}",
            lambda privilege=privilege: client.request(
                "PUT",
                f"/api/management/v1/catalogs/{POLARIS_CATALOG_NAME}/catalog-roles/{catalog_role}/grants",
                {"type": "catalog", "privilege": privilege},
            ),
        )
        if error:
            flash(error)
            return redirect(url_for("index"))

    if created_credentials:
        save_credentials(principal, created_credentials)
    flash(
        f"Created {principal}, linked {principal_role} -> {catalog_role}, "
        f"and granted: {', '.join(privileges)}. Credentials were appended to {CREDENTIAL_LOG}."
    )
    return redirect(url_for("index"))


@app.post("/grant-privilege")
@require_basic_auth
def grant_privilege():
    catalog_role = request.form["catalog_role"].strip()
    privilege = request.form["privilege"].strip()
    _, error = safe_api(
        f"Grant {privilege}",
        lambda: polaris().request(
            "PUT",
            f"/api/management/v1/catalogs/{POLARIS_CATALOG_NAME}/catalog-roles/{catalog_role}/grants",
            {"type": "catalog", "privilege": privilege},
        ),
    )
    flash(error or f"Granted {privilege} to catalog role {catalog_role}.")
    return redirect(url_for("index"))


@app.get("/health")
def health():
    return {"status": "ok"}

