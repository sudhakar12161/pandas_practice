#!/usr/bin/env sh
set -eu

mkdir -p /etc/trino/catalog

sed \
  -e "s|\${RUSTFS_ACCESS_KEY}|${RUSTFS_ACCESS_KEY}|g" \
  -e "s|\${RUSTFS_SECRET_KEY}|${RUSTFS_SECRET_KEY}|g" \
  -e "s|\${RUSTFS_REGION}|${RUSTFS_REGION}|g" \
  -e "s|\${RUSTFS_BUCKET}|${RUSTFS_BUCKET}|g" \
  -e "s|\${POLARIS_CATALOG_NAME}|${POLARIS_CATALOG_NAME}|g" \
  -e "s|\${POLARIS_ROOT_CLIENT_ID}|${POLARIS_ROOT_CLIENT_ID}|g" \
  -e "s|\${POLARIS_ROOT_CLIENT_SECRET}|${POLARIS_ROOT_CLIENT_SECRET}|g" \
  /templates/iceberg.properties.template > /etc/trino/catalog/iceberg.properties

exec /usr/lib/trino/bin/run-trino
